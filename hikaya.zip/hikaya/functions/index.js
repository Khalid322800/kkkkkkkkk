const { onValueCreated } = require('firebase-functions/v2/database');
const { initializeApp } = require('firebase-admin/app');
const { getDatabase } = require('firebase-admin/database');
const { getMessaging } = require('firebase-admin/messaging');
const { getAuth } = require('firebase-admin/auth');
const { onCall, HttpsError } = require('firebase-functions/v2/https');

initializeApp();

exports.dispatchHikayaNotification = onValueCreated('/notifications/{notificationId}', async (event) => {
  const notification = event.data.val() || {};
  if (notification.status !== 'QUEUED') return null;

  const tokenTree = await getDatabase().ref('fcmTokens').get();
  const tokens = [];
  tokenTree.forEach((user) => user.forEach((token) => tokens.push(token.key)));
  if (!tokens.length) {
    await event.data.ref.update({ status: 'NO_RECIPIENTS', sentAt: Date.now(), recipientCount: 0 });
    return null;
  }

  const messaging = getMessaging();
  const chunks = [];
  for (let i = 0; i < tokens.length; i += 500) chunks.push(tokens.slice(i, i + 500));

  let successCount = 0;
  let failureCount = 0;
  for (const chunk of chunks) {
    const response = await messaging.sendEachForMulticast({
      tokens: chunk,
      notification: { title: String(notification.title || 'حكاية'), body: String(notification.body || '') },
      data: { storyId: String(notification.storyId || ''), notificationId: event.params.notificationId }
    });
    successCount += response.successCount;
    failureCount += response.failureCount;
  }

  await event.data.ref.update({
    status: failureCount ? 'SENT_WITH_ERRORS' : 'SENT',
    sentAt: Date.now(),
    recipientCount: successCount,
    failureCount
  });
  return null;
});

exports.setHikayaAdminRole = onCall(async (request) => {
  if (!request.auth?.token?.admin || request.auth.token.username !== 'KHALID776532240') {
    throw new HttpsError('permission-denied', 'حساب المدير الأساسي مطلوب.');
  }
  const uid = String(request.data?.uid || '');
  const role = String(request.data?.role || 'Viewer');
  if (!uid || !['Super Admin', 'Content Manager', 'Moderator', 'Viewer'].includes(role)) {
    throw new HttpsError('invalid-argument', 'المستخدم أو الدور غير صالح.');
  }
  const admin = role === 'Super Admin';
  await getAuth().setCustomUserClaims(uid, { admin, username: request.data.username || '', role });
  return { ok: true, uid, role };
});
