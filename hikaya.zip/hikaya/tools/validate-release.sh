#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 - <<'PY'
from pathlib import Path
import json
import xml.etree.ElementTree as ET
for p in Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
for p in [Path('firebase/database.rules.json'), Path('firebase/firebase.json'), Path('functions/package.json')]:
    json.loads(p.read_text())
for p in Path('app/src/main/java').rglob('*.kt'):
    text = p.read_text()
    clean=[]; quoted=False; escaped=False
    for ch in text:
        if escaped:
            escaped=False
            continue
        if ch == '\\' and quoted:
            escaped=True
            continue
        if ch == '"':
            quoted=not quoted
            continue
        if not quoted:
            clean.append(ch)
    stripped=''.join(clean)
    if stripped.count('{') != stripped.count('}'):
        raise SystemExit(f'Unbalanced braces: {p}')
print('STATIC_RELEASE_CHECK_OK')
PY
node --check functions/index.js
if find . -type f \( -name '*.pem' -o -name '*.key' -o -name '*service-account*' \) -not -path './.git/*' | grep -q .; then
  echo 'SECRET_FILE_FOUND' >&2
  exit 1
fi
printf '%s\n' 'NO_EMBEDDED_ADMIN_KEYS'
printf '%s\n' 'Run Gradle assembleDebug and assembleRelease on a machine with Android SDK configured.'
