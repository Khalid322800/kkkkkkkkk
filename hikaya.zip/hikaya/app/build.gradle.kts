import java.io.FileInputStream
import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

/*
 * قراءة بيانات توقيع Release من ملف خارجي.
 *
 * مكان الملف:
 * Hikaya/keystore.properties
 *
 * لا تضع كلمات المرور داخل هذا الملف أو داخل Git.
 */
val keystorePropertiesFile = rootProject.file("keystore.properties")
val keystoreProperties = Properties()

if (keystorePropertiesFile.exists()) {
    FileInputStream(keystorePropertiesFile).use {
        keystoreProperties.load(it)
    }
}

android {
    namespace = "com.khalid.hikaya"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.khalid.hikaya"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    /*
     * إعداد توقيع نسخة Release
     *
     * Alias الصحيح لملفك هو:
     * key
     */
    signingConfigs {
        create("release") {
            if (keystorePropertiesFile.exists()) {
                val storeFilePath =
                    keystoreProperties["storeFile"]?.toString()
                        ?: error("storeFile غير موجود في keystore.properties")

                val storePasswordValue =
                    keystoreProperties["storePassword"]?.toString()
                        ?: error("storePassword غير موجود في keystore.properties")

                val keyAliasValue =
                    keystoreProperties["keyAlias"]?.toString()
                        ?: error("keyAlias غير موجود في keystore.properties")

                val keyPasswordValue =
                    keystoreProperties["keyPassword"]?.toString()
                        ?: error("keyPassword غير موجود في keystore.properties")

                storeFile = rootProject.file(storeFilePath)
                storePassword = storePasswordValue
                keyAlias = keyAliasValue
                keyPassword = keyPasswordValue
            }
        }
    }

    buildTypes {
        getByName("debug") {
            // يستخدم توقيع Debug الافتراضي من Android.
        }

        getByName("release") {
            isMinifyEnabled = false
            isShrinkResources = false

            signingConfig = signingConfigs.getByName("release")
        }
    }

    buildFeatures {
        viewBinding = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.work:work-runtime-ktx:2.9.0")

    // Firebase
    implementation(platform("com.google.firebase:firebase-bom:33.9.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("com.google.firebase:firebase-database")
    implementation("com.google.firebase:firebase-messaging")

    // Google Sign-In
    implementation("com.google.android.gms:play-services-auth:20.7.0")

    // بصمة الإصبع
    implementation("androidx.biometric:biometric:1.2.0-alpha05")
}
