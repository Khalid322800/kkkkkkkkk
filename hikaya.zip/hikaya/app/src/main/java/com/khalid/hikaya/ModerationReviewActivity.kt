package com.khalid.hikaya

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore

class ModerationReviewActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private var items = listOf<ReviewItem>()
    private var query = ""
    private var filter = Filter.ALL

    private enum class Filter { ALL, DRAFTS, REPORTS, TASKS }
    private enum class Source { DRAFT, REPORT, TASK }
    private data class ReviewItem(
        val source: Source,
        val id: String,
        val title: String,
        val subtitle: String,
        val state: String,
        val priority: String,
        val storyId: String = ""
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = AdminUi.root(this)
        root.addView(AdminUi.title(this, "مركز المراجعة", "تابع المسودات والبلاغات والمهام التي تحتاج تدخل المدير."))
        val filterButton = AdminUi.button(this, "كل المهام")
        root.addView(filterButton, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 46)).apply { topMargin = AdminUi.dp(this@ModerationReviewActivity, 18) })
        val search = AdminUi.search(this, "ابحث في المهام أو القصص أو البلاغات...")
        root.addView(search, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 50)).apply { topMargin = AdminUi.dp(this@ModerationReviewActivity, 10) })
        status = TextView(this).apply {
            setTextColor(AdminUi.MUTED)
            textSize = 13f
            setPadding(0, 14, 0, 8)
            setOnClickListener { load() }
        }
        root.addView(status)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        filterButton.setOnClickListener {
            val options = arrayOf("كل المهام", "المسودات", "البلاغات", "مهام المراجعة")
            AlertDialog.Builder(this).setTitle("نوع المهمة").setItems(options) { _, which ->
                filter = when (which) { 1 -> Filter.DRAFTS; 2 -> Filter.REPORTS; 3 -> Filter.TASKS; else -> Filter.ALL }
                filterButton.text = options[which]
                render()
            }.show()
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s?.toString().orEmpty(); render() }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    override fun onResume() { super.onResume(); if (::list.isInitialized) load() }

    private fun load() {
        status.text = "جارٍ تحميل مركز المراجعة…"
        AdminAuth.verifyCurrentAdmin { isAdmin, _ ->
            if (!isAdmin) {
                status.text = "جلسة المدير غير صالحة. سجّل الخروج ثم ادخل مجددًا."
                return@verifyCurrentAdmin
            }
            val draftsTask = db.collection("stories").whereEqualTo("isPublished", false).get()
            val reportsTask = db.collection("reports").get()
            val queueTask = db.collection("moderation_queue").get()
            draftsTask.addOnSuccessListener { drafts ->
                reportsTask.addOnSuccessListener { reports ->
                    queueTask.addOnSuccessListener { queue ->
                        items = buildItems(drafts.documents, reports.documents, queue.documents)
                        render()
                    }.addOnFailureListener { showError("مهام المراجعة", it) }
                }.addOnFailureListener { showError("البلاغات", it) }
            }.addOnFailureListener { showError("المسودات", it) }
        }
    }

    private fun buildItems(drafts: List<DocumentSnapshot>, reports: List<DocumentSnapshot>, queue: List<DocumentSnapshot>): List<ReviewItem> {
        val draftItems = drafts.map { d ->
            ReviewItem(Source.DRAFT, d.id, d.getString("title").orEmpty().ifBlank { "قصة بدون عنوان" }, "مسودة قصة • ${d.getString("categoryName").orEmpty().ifBlank { "قسم غير محدد" }}", "DRAFT", "NORMAL", d.id)
        }
        val reportItems = reports.map { d ->
            ReviewItem(Source.REPORT, d.id, d.getString("reason").orEmpty().ifBlank { "بلاغ محتوى" }, d.getString("details").orEmpty().ifBlank { "بلاغ يحتاج مراجعة" }, d.getString("status") ?: "NEW", d.getString("priority") ?: "NORMAL", d.getString("storyId").orEmpty())
        }
        val queueItems = queue.map { d ->
            ReviewItem(Source.TASK, d.id, d.getString("title").orEmpty().ifBlank { "مهمة مراجعة" }, d.getString("description").orEmpty().ifBlank { "مهمة تحتاج تدخل المدير" }, d.getString("status") ?: "NEW", d.getString("priority") ?: "NORMAL", d.getString("storyId").orEmpty())
        }
        return (draftItems + reportItems + queueItems).sortedWith(compareByDescending<ReviewItem> { it.priority == "HIGH" }.thenBy { it.state })
    }

    private fun render() {
        if (!::list.isInitialized) return
        val q = query.trim()
        val visible = items.filter { item ->
            val matchesType = when (filter) {
                Filter.ALL -> true
                Filter.DRAFTS -> item.source == Source.DRAFT
                Filter.REPORTS -> item.source == Source.REPORT
                Filter.TASKS -> item.source == Source.TASK
            }
            matchesType && (q.isBlank() || item.title.contains(q, true) || item.subtitle.contains(q, true) || item.storyId.contains(q, true))
        }
        status.text = "${visible.size} مهمة ظاهرة • مسودات ${items.count { it.source == Source.DRAFT }} • بلاغات ${items.count { it.source == Source.REPORT }} • مهام ${items.count { it.source == Source.TASK }}"
        list.removeAllViews()
        if (visible.isEmpty()) {
            list.addView(TextView(this).apply { text = "لا توجد مهام مراجعة مطابقة"; setTextColor(AdminUi.MUTED); setPadding(0, 18, 0, 0) })
            return
        }
        visible.forEach { item ->
            val card = AdminUi.card(this)
            card.addView(TextView(this).apply { text = item.title; textSize = 16f; setTextColor(AdminUi.NAVY); setTypeface(null, 1) })
            card.addView(TextView(this).apply { text = "${sourceLabel(item.source)}  •  ${stateLabel(item.state)}  •  ${priorityLabel(item.priority)}"; textSize = 12f; setTextColor(if (item.priority == "HIGH") 0xFFB66A3C.toInt() else AdminUi.MUTED); setPadding(0, 6, 0, 4) })
            card.addView(TextView(this).apply { text = item.subtitle; textSize = 13f; setTextColor(0xFF202127.toInt()); setPadding(0, 0, 0, 8) })
            val action = AdminUi.button(this, if (item.source == Source.DRAFT) "مراجعة ونشر" else "معالجة المهمة")
            card.addView(action)
            action.setOnClickListener { handleItem(item) }
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
    }

    private fun handleItem(item: ReviewItem) {
        if (item.source == Source.DRAFT) {
            AlertDialog.Builder(this).setTitle("المسودة: ${item.title}")
                .setItems(arrayOf("نشر القصة", "الإبقاء كمسودة")) { _, which ->
                    if (which == 0) db.collection("stories").document(item.id).update("isPublished", true, "updatedAt", System.currentTimeMillis()).addOnSuccessListener { load() }
                }.show()
            return
        }
        val options = arrayOf("قيد المراجعة", "تمت المعالجة", "مرفوضة", "مغلقة")
        AlertDialog.Builder(this).setTitle("حالة المهمة").setItems(options) { _, which ->
            val state = when (which) { 1 -> "COMPLETED"; 2 -> "REJECTED"; 3 -> "CLOSED"; else -> "IN_REVIEW" }
            val collection = if (item.source == Source.REPORT) "reports" else "moderation_queue"
            db.collection(collection).document(item.id).update("status", state, "reviewedAt", System.currentTimeMillis()).addOnSuccessListener { load() }
                .addOnFailureListener { showError("تحديث المهمة", it) }
        }.show()
    }

    private fun showError(action: String, error: Exception) {
        status.text = "تعذر تحميل $action: ${error.localizedMessage.orEmpty()} • اضغط هنا لإعادة المحاولة"
    }

    private fun sourceLabel(source: Source) = when (source) { Source.DRAFT -> "مسودة"; Source.REPORT -> "بلاغ"; Source.TASK -> "مراجعة" }
    private fun stateLabel(state: String) = when (state) { "DRAFT" -> "مسودة"; "COMPLETED" -> "تمت المعالجة"; "REJECTED" -> "مرفوضة"; "CLOSED" -> "مغلقة"; "IN_REVIEW" -> "قيد المراجعة"; else -> "جديدة" }
    private fun priorityLabel(priority: String) = if (priority == "HIGH") "أولوية عالية" else "أولوية عادية"
}
