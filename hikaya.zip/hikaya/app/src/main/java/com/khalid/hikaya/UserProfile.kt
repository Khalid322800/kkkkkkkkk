package com.khalid.hikaya

data class UserProfile(
    val userId: String,
    val username: String,
    val createdAt: Long
)
