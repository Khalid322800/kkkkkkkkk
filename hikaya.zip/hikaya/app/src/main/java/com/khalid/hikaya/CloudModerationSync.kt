package com.khalid.hikaya

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

/** مزامنة اختيارية؛ لا تمنع القراءة أو الحفظ المحلي عند انقطاع الشبكة. */
object CloudModerationSync {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }

    fun syncComment(context: Context, storyId: Int, comment: StoryReaderStore.Comment) {
        withAuthenticatedUser {
            db.collection("comments").document(comment.id).set(
                mapOf(
                    "id" to comment.id,
                    "storyId" to storyId.toString(),
                    "userId" to comment.userId,
                    "username" to comment.name,
                    "text" to comment.text,
                    "time" to comment.time,
                    "status" to "PENDING",
                    "authUid" to auth.currentUser?.uid,
                    "createdAt" to System.currentTimeMillis()
                )
            )
        }
    }

    fun syncRating(context: Context, storyId: Int, userId: String, rating: Int) {
        withAuthenticatedUser {
            val id = "${storyId}_$userId"
            db.collection("ratings").document(id).set(
                mapOf(
                    "id" to id,
                    "storyId" to storyId.toString(),
                    "userId" to userId,
                    "rating" to rating,
                    "status" to "PUBLISHED",
                    "authUid" to auth.currentUser?.uid,
                    "createdAt" to System.currentTimeMillis()
                )
            )
        }
    }

    private fun withAuthenticatedUser(action: () -> Unit) {
        if (auth.currentUser != null) {
            action()
        } else {
            auth.signInAnonymously().addOnSuccessListener { action() }
        }
    }
}
