package com.khalid.hikaya

data class StoryCategory(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val stories: List<Story> = emptyList()
)
