package com.khalid.hikaya

import com.google.firebase.auth.FirebaseAuth

/**
 * مصدر واحد لإعدادات هوية المدير والتحقق من Custom Claims.
 * لا يحتوي على كلمة مرور أو مفتاح إداري.
 */
object AdminAuth {
    const val USERNAME = "KHALID776532240"
    const val EMAIL = "khalid776532240@hikaya.app"

    private val auth: FirebaseAuth
        get() = FirebaseAuth.getInstance()

    fun verifyCurrentAdmin(
        onResult: (isAdmin: Boolean, username: String?) -> Unit
    ) {
        val user = auth.currentUser
        if (user == null) {
            onResult(false, null)
            return
        }

        user.getIdToken(true)
            .addOnSuccessListener { tokenResult ->
                val claims = tokenResult.claims
                val isAdmin = claims["admin"] == true && claims["username"] == USERNAME
                onResult(isAdmin, claims["username"] as? String)
            }
            .addOnFailureListener {
                onResult(false, null)
            }
    }

    fun signOut() {
        auth.signOut()
    }
}
