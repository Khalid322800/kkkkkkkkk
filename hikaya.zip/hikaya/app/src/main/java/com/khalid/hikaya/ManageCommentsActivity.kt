package com.khalid.hikaya

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore

class ManageCommentsActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private var docs = listOf<DocumentSnapshot>()
    private var query = ""
    private var filter = "ALL"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = AdminUi.root(this)
        root.addView(AdminUi.title(this, "مراجعة التعليقات", "راجع تعليقات القراء قبل ظهورها في المحتوى."))
        val search = AdminUi.search(this, "ابحث باسم المستخدم أو نص التعليق...")
        root.addView(search, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 50)).apply { topMargin = AdminUi.dp(this@ManageCommentsActivity, 18) })
        val filterButton = AdminUi.button(this, "كل الحالات")
        root.addView(filterButton, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 46)).apply { topMargin = AdminUi.dp(this@ManageCommentsActivity, 10) })
        status = TextView(this).apply { setTextColor(AdminUi.MUTED); textSize = 13f; setPadding(0, 14, 0, 8) }
        root.addView(status)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        filterButton.setOnClickListener {
            val options = arrayOf("كل الحالات", "قيد المراجعة", "مقبولة", "مرفوضة")
            AlertDialog.Builder(this).setTitle("فلترة التعليقات").setItems(options) { _, which ->
                filter = when (which) { 1 -> "PENDING"; 2 -> "APPROVED"; 3 -> "REJECTED"; else -> "ALL" }
                filterButton.text = options[which]
                render()
            }.show()
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s?.toString().orEmpty(); render() }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    override fun onResume() { super.onResume(); if (::list.isInitialized) load() }

    private fun load() {
        status.text = "جارٍ تحميل التعليقات…"
        db.collection("comments").get().addOnSuccessListener {
            docs = it.documents.sortedByDescending { d -> number(d, "createdAt") }
            render()
        }.addOnFailureListener { status.text = "تعذر تحميل التعليقات: ${it.localizedMessage.orEmpty()}" }
    }

    private fun render() {
        if (!::list.isInitialized) return
        val q = query.trim()
        val items = docs.filter { d ->
            val state = d.getString("status") ?: "PENDING"
            val text = d.getString("text").orEmpty()
            val user = d.getString("username").orEmpty()
            (filter == "ALL" || state == filter) && (q.isBlank() || text.contains(q, true) || user.contains(q, true))
        }
        status.text = "${items.size} تعليق من ${docs.size}"
        list.removeAllViews()
        if (items.isEmpty()) {
            list.addView(TextView(this).apply { text = "لا توجد تعليقات مطابقة"; setTextColor(AdminUi.MUTED); setPadding(0, 18, 0, 0) })
            return
        }
        items.forEach { document ->
            val id = document.id
            val user = document.getString("username").orEmpty().ifBlank { "مستخدم حكاية" }
            val text = document.getString("text").orEmpty()
            val state = document.getString("status") ?: "PENDING"
            val card = AdminUi.card(this)
            card.addView(TextView(this).apply { this.text = user; textSize = 16f; setTextColor(AdminUi.NAVY); setTypeface(null, 1) })
            card.addView(TextView(this).apply { this.text = text; textSize = 14f; setTextColor(0xFF202127.toInt()); setPadding(0, 7, 0, 5) })
            card.addView(TextView(this).apply { this.text = "${stateLabel(state)}  •  قصة: ${document.getString("storyId").orEmpty()}"; textSize = 11f; setTextColor(AdminUi.MUTED); setPadding(0, 0, 0, 8) })
            val actions = LinearLayout(this)
            val review = AdminUi.button(this, "مراجعة")
            val delete = AdminUi.button(this, "حذف")
            actions.addView(review, LinearLayout.LayoutParams(0, -2, 1f))
            actions.addView(delete, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = 8 })
            card.addView(actions)
            review.setOnClickListener { reviewComment(id, state) }
            delete.setOnClickListener { deleteComment(id) }
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
    }

    private fun reviewComment(id: String, current: String) {
        val options = arrayOf("قبول التعليق", "رفض التعليق", "إعادته للمراجعة")
        AlertDialog.Builder(this).setTitle("حالة التعليق").setItems(options) { _, which ->
            val state = when (which) { 0 -> "APPROVED"; 1 -> "REJECTED"; else -> "PENDING" }
            db.collection("comments").document(id).update("status", state, "reviewedAt", System.currentTimeMillis())
                .addOnSuccessListener { load() }
                .addOnFailureListener { status.text = "تعذر تحديث التعليق: ${it.localizedMessage.orEmpty()}" }
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun deleteComment(id: String) {
        AlertDialog.Builder(this).setTitle("حذف التعليق").setMessage("هل تريد حذف التعليق نهائيًا؟")
            .setNegativeButton("إلغاء", null).setPositiveButton("حذف") { _, _ ->
                db.collection("comments").document(id).delete().addOnSuccessListener { load() }
                    .addOnFailureListener { status.text = "تعذر حذف التعليق: ${it.localizedMessage.orEmpty()}" }
            }.show()
    }

    private fun stateLabel(state: String) = when (state) { "APPROVED" -> "مقبول"; "REJECTED" -> "مرفوض"; else -> "قيد المراجعة" }
    private fun number(d: DocumentSnapshot, key: String) = (d.get(key) as? Number)?.toLong() ?: 0L
}
