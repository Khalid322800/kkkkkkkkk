package com.khalid.hikaya

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessaging

object FcmTokenRegistrar {
    fun registerCurrentDevice() {
        val auth = FirebaseAuth.getInstance()
        val register = { uid: String ->
            FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
                FirebaseDatabase.getInstance().reference
                    .child("fcmTokens")
                    .child(uid)
                    .child(token)
                    .setValue(true)
            }
        }

        val currentUser = auth.currentUser
        if (currentUser != null) {
            register(currentUser.uid)
        } else {
            // المستخدم العادي لا يملك حسابًا دائمًا؛ الحساب المجهول يكفي
            // لربط الجهاز بالإشعارات دون كشف بيانات شخصية.
            auth.signInAnonymously()
                .addOnSuccessListener { result -> register(result.user?.uid ?: return@addOnSuccessListener) }
        }
    }
}
