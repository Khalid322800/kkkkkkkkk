package com.khalid.hikaya

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class AdminLoginActivity : AppCompatActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private lateinit var usernameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var statusText: TextView
    private lateinit var loginButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_login)

        usernameInput = findViewById(R.id.adminUsernameInput)
        passwordInput = findViewById(R.id.adminPasswordInput)
        statusText = findViewById(R.id.adminLoginStatus)
        loginButton = findViewById(R.id.adminLoginButton)

        findViewById<TextView>(R.id.adminLoginBack).setOnClickListener { finish() }
        loginButton.setOnClickListener { signIn() }
    }

    private fun signIn() {
        val username = usernameInput.text?.toString()?.trim().orEmpty()
        val password = passwordInput.text?.toString().orEmpty()

        if (username != AdminAuth.USERNAME) {
            usernameInput.error = "اسم المستخدم الإداري غير صحيح"
            return
        }
        if (password.isBlank()) {
            passwordInput.error = "أدخل كلمة المرور"
            return
        }

        setLoading(true)
        auth.signInWithEmailAndPassword(AdminAuth.EMAIL, password)
            .addOnSuccessListener {
                val user = auth.currentUser
                if (user == null) {
                    showError("تعذر إنشاء جلسة آمنة")
                    return@addOnSuccessListener
                }
                user.getIdToken(true)
                    .addOnSuccessListener { tokenResult ->
                        val claims = tokenResult.claims
                        val valid = claims["admin"] == true && claims["username"] == AdminAuth.USERNAME
                        if (valid) {
                            startActivity(Intent(this, AdminActivity::class.java))
                            finish()
                        } else {
                            AdminAuth.signOut()
                            showError("هذا الحساب لا يملك صلاحية المدير")
                        }
                    }
                    .addOnFailureListener { showError("تعذر التحقق من صلاحية المدير") }
            }
            .addOnFailureListener { showError("بيانات الدخول غير صحيحة أو الحساب غير متاح") }
    }

    private fun setLoading(loading: Boolean) {
        loginButton.isEnabled = !loading
        usernameInput.isEnabled = !loading
        passwordInput.isEnabled = !loading
        statusText.text = if (loading) "جارٍ التحقق من الحساب…" else ""
    }

    private fun showError(message: String) {
        setLoading(false)
        statusText.text = message
    }
}
