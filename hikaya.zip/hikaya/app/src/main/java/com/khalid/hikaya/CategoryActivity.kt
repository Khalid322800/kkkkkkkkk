package com.khalid.hikaya

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

/** يعرض الفروع والقصص التابعة للقسم المحدد، بمستويات غير محدودة. */
class CategoryActivity : AppCompatActivity() {
    companion object { const val EXTRA_CATEGORY_ID = "category_id" }
    private val db by lazy { FirebaseFirestore.getInstance() }
    private lateinit var content: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var empty: TextView
    private lateinit var categoryId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        categoryId = intent.getStringExtra(EXTRA_CATEGORY_ID).orEmpty()
        if (categoryId.isBlank()) { finish(); return }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(dp(18), dp(18), dp(18), dp(18)); setBackgroundColor(Color.rgb(247, 246, 242)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply { text = "‹"; textSize = 34f; setTextColor(Color.rgb(174,135,59)); setPadding(0,0,dp(12),0); setOnClickListener { finish() } })
        header.addView(TextView(this).apply { text = intent.getStringExtra("category_title") ?: "القسم"; textSize = 23f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(25,43,65)) })
        root.addView(header)
        progress = ProgressBar(this)
        root.addView(progress, LinearLayout.LayoutParams(-2,-2).apply { gravity = Gravity.CENTER; topMargin = dp(18) })
        empty = TextView(this).apply { text = "لا توجد عناصر داخل هذا القسم بعد."; textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.GRAY); visibility = View.GONE; setPadding(dp(8), dp(22), dp(8), dp(22)) }
        root.addView(empty)
        val scroll = android.widget.ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(18), 0, 0) }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }

    override fun onResume() { super.onResume(); if (::content.isInitialized) loadChildren() }

    private fun loadChildren() {
        progress.visibility = View.VISIBLE; empty.visibility = View.GONE; content.removeAllViews()
        db.collection("categories")
            .whereEqualTo("parentId", categoryId)
            .whereEqualTo("isActive", true)
            .get()
            .addOnSuccessListener { categories ->
            val children = categories.documents.filter { doc ->
                (doc.getString("parentId") == categoryId) && doc.getBoolean("isActive") != false
            }.sortedBy { it.getLong("order") ?: 0L }
            db.collection("stories")
                .whereEqualTo("categoryId", categoryId)
                .whereEqualTo("isPublished", true)
                .get()
                .addOnSuccessListener { stories ->
                progress.visibility = View.GONE
                var count = 0
                children.forEach { doc ->
                    val name = doc.getString("name").orEmpty(); if (name.isBlank()) return@forEach
                    content.addView(itemCard(doc.getString("icon") ?: "folder", name, doc.getString("description").orEmpty()) {
                        startActivity(Intent(this, CategoryActivity::class.java).putExtra(EXTRA_CATEGORY_ID, doc.id).putExtra("category_title", name))
                    }); count++
                }
                val storyDocs = stories.documents.filter { doc ->
                    val published = doc.getBoolean("isPublished") != false
                    val parent = doc.getString("categoryId") ?: doc.getString("category") ?: doc.getString("branch")
                    published && parent == categoryId
                }.sortedBy { it.getLong("order") ?: 0L }
                storyDocs.forEach { doc ->
                    val title = doc.getString("title").orEmpty(); if (title.isBlank()) return@forEach
                    content.addView(itemCard("file-text", title, doc.getString("description").orEmpty().ifBlank { "قصة قابلة للقراءة" }) {
                        startActivity(Intent(this, StoryActivity::class.java).putExtra(StoryActivity.EXTRA_STORY_ID, doc.id))
                    }); count++
                }
                empty.visibility = if (count == 0) View.VISIBLE else View.GONE
            }.addOnFailureListener { failLoad(it.localizedMessage) }
        }.addOnFailureListener { failLoad(it.localizedMessage) }
    }

    private fun failLoad(message: String?) { progress.visibility = View.GONE; empty.visibility = View.VISIBLE; empty.text = "تعذر تحميل المحتوى. تحقق من الاتصال والصلاحيات.\n${message ?: ""}" }

    private fun itemCard(icon: String, title: String, description: String, click: () -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(16).toFloat(); setStroke(dp(1), Color.rgb(228,225,217)) }; isClickable = true; isFocusable = true; setOnClickListener { click() } }
        row.addView(TextView(this).apply { text = if (icon == "file-text") "▤" else "▣"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(Color.rgb(174,135,59)); layoutParams = LinearLayout.LayoutParams(dp(48),dp(48)); background = GradientDrawable().apply { setColor(Color.rgb(247,241,226)); cornerRadius = dp(12).toFloat() } })
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,dp(4),0); layoutParams = LinearLayout.LayoutParams(0,-2,1f) }
        labels.addView(TextView(this).apply { text = title; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(31,38,47)) })
        if (description.isNotBlank()) labels.addView(TextView(this).apply { text = description; textSize = 13f; setTextColor(Color.GRAY); setPadding(0,dp(4),0,0); maxLines = 2 })
        row.addView(labels)
        return row.also { it.layoutParams = LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = dp(10) } }
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
