package com.khalid.hikaya

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.text.Editable
import android.text.SpannableString
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.view.ActionMode
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.khalid.hikaya.databinding.ActivityStoryBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class StoryActivity : AppCompatActivity() {
    companion object { const val EXTRA_STORY_ID = "story_id" }

    private lateinit var binding: ActivityStoryBinding
    private lateinit var story: Story
    private var storyId = -1
    private val prefs get() = StoryReaderStore

    private val searchMatches = mutableListOf<Int>()
    private var searchIndex = 0
    private var chromeVisible = true
    private var mode = "night"
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var moved = false
    private var suppressScrollSave = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val requestedId = intent.getStringExtra(EXTRA_STORY_ID)
            ?: intent.getIntExtra(EXTRA_STORY_ID, -1).takeIf { it >= 0 }?.toString()
        if (requestedId.isNullOrBlank()) { finish(); return }
        storyId = requestedId.toIntOrNull() ?: requestedId.hashCode()
        val localStory = StoryRepository.findStory(requestedId)
        if (localStory != null) {
            initializeStory(localStory)
        } else {
            // القصص المنشأة من لوحة التحكم تُحمّل من Firestore حسب معرّف المستند.
            com.google.firebase.firestore.FirebaseFirestore.getInstance()
                .collection("stories").document(requestedId).get()
                .addOnSuccessListener { doc ->
                    if (!doc.exists()) { Toast.makeText(this, "القصة غير موجودة", Toast.LENGTH_LONG).show(); finish(); return@addOnSuccessListener }
                    val data = doc.data.orEmpty()
                    val loaded = Story(
                        id = doc.id,
                        title = data["title"] as? String ?: "قصة بدون عنوان",
                        content = data["content"] as? String ?: "",
                        description = data["description"] as? String ?: "",
                        category = data["categoryName"] as? String ?: data["category"] as? String ?: "",
                        imageUrl = "", rating = (data["rating"] as? Number)?.toFloat() ?: 5f,
                        views = (data["views"] as? Number)?.toInt() ?: 0,
                        duration = (data["duration"] as? Number)?.toInt() ?: 0,
                        timestamp = (data["timestamp"] as? Number)?.toLong() ?: 0L
                    )
                    if (loaded.content.isBlank()) { Toast.makeText(this, "محتوى القصة فارغ", Toast.LENGTH_LONG).show(); finish(); return@addOnSuccessListener }
                    initializeStory(loaded)
                }
                .addOnFailureListener { e -> Toast.makeText(this, "تعذر تحميل القصة: ${e.localizedMessage}", Toast.LENGTH_LONG).show(); finish() }
        }
    }

    private fun initializeStory(loaded: Story) {
        story = loaded
        storyId = loaded.id.toIntOrNull() ?: loaded.id.hashCode()
        setupActions()
        setupSelectionBookmarks()
        setupScroll()
        loadStory(loaded, false)
        applyTheme()
        restorePosition()
    }

    private fun setupActions() {
        binding.backButton.setOnClickListener { finish() }
        binding.favoriteButton.setOnClickListener {
            prefs.toggleFavorite(this, storyId)
            updateFavoriteIcon()
        }
        binding.searchButton.setOnClickListener { openSearch() }
        binding.searchClose.setOnClickListener { closeSearch() }
        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateSearchResults() }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        binding.searchPrev.setOnClickListener { moveSearch(-1) }
        binding.searchNext.setOnClickListener { moveSearch(1) }

        binding.moreButton.setOnClickListener { showMoreActions(binding.moreButton) }
        binding.readingModeButton.setOnClickListener { showModePopup(binding.readingModeButton) }
        binding.settingsButton.setOnClickListener { showReaderSettings(binding.settingsButton) }
        binding.ratingClose.setOnClickListener { closeRatingPanel() }
        binding.commentsClose.setOnClickListener { closeCommentsPanel() }

        binding.previousButton.setOnClickListener { switchStory(-1) }
        binding.nextButton.setOnClickListener { switchStory(1) }

        binding.storyText.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                    downTime = System.currentTimeMillis()
                    moved = false
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(event.x - downX) > ViewConfiguration.get(this).scaledTouchSlop ||
                        abs(event.y - downY) > ViewConfiguration.get(this).scaledTouchSlop) moved = true
                    false
                }
                MotionEvent.ACTION_UP -> {
                    val quick = System.currentTimeMillis() - downTime <= 350L
                    if (!moved && quick) toggleChrome()
                    false
                }
                else -> false
            }
        }
    }

    private fun setupScroll() {
        binding.storyScroll.viewTreeObserver.addOnScrollChangedListener {
            if (suppressScrollSave) return@addOnScrollChangedListener
            if (prefs.isSavePositionEnabled(this)) prefs.savePosition(this, storyId, binding.storyScroll.scrollY)
        }
    }

    private fun setupSelectionBookmarks() {
        binding.storyText.customSelectionActionModeCallback = object : ActionMode.Callback {
            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                menu.add("حفظ علامة").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
                return true
            }
            override fun onPrepareActionMode(mode: ActionMode, menu: Menu) = false
            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
                if (item.title == "حفظ علامة") {
                    val start = binding.storyText.selectionStart.coerceAtLeast(0)
                    val end = binding.storyText.selectionEnd.coerceAtLeast(start)
                    if (end > start) {
                        val selected = binding.storyText.text.substring(start, end)
                        prefs.addBookmark(this@StoryActivity, storyId, start, selected)
                        renderStoryText()
                        Toast.makeText(this@StoryActivity, "تم حفظ العلامة", Toast.LENGTH_SHORT).show()
                    }
                    mode.finish()
                    return true
                }
                return false
            }
            override fun onDestroyActionMode(mode: ActionMode) = Unit
        }
    }

    private fun loadStory(newStory: Story, restore: Boolean) {
        story = newStory
        storyId = newStory.id.toIntOrNull() ?: newStory.id.hashCode()
        binding.storyCategory.text = newStory.category
        binding.storyTitle.text = newStory.title
        binding.topTitle.text = newStory.title
        binding.storyRating.text = "★ ${newStory.rating}"
        clearSearchForNewStory()
        closeRatingPanel()
        closeCommentsPanel()
        renderStoryText()
        renderComments()
        renderRatingState()
        updateFavoriteIcon()
        updateNavButtons()
        if (restore) restorePosition()
    }

    private fun renderStoryText() {
        val source = story.content
        binding.storyText.text = SpannableString(source)
        applySavedSettings()
        applyBookmarkHighlights()
        if (binding.searchInput.text?.isNotBlank() == true) updateSearchResults() else clearSearchHighlights()
    }

    private fun applySavedSettings() {
        val size = prefs.getInt(this, "font_size", 20).coerceIn(16, 26)
        val lineMultiplier = prefs.getFloat(this, "line_spacing", 1.55f).coerceIn(1.20f, 1.90f)
        val width = prefs.getInt(this, "text_width", 92).coerceIn(70, 100)
        val font = prefs.getString(this, "font", "amiri")

        binding.storyText.textSize = size.toFloat()
        binding.storyText.setLineSpacing(0f, lineMultiplier)
        binding.storyText.typeface = fontTypeface(font)
        binding.storyText.gravity = Gravity.RIGHT

        val marginDp = ((100 - width) * 0.42f).toInt().coerceIn(0, 15)
        val lp = binding.storyText.layoutParams as LinearLayout.LayoutParams
        lp.marginStart = dp(marginDp)
        lp.marginEnd = dp(marginDp)
        binding.storyText.layoutParams = lp
    }

    private fun fontTypeface(key: String): Typeface = when (key) {
        "amiri" -> androidx.core.content.res.ResourcesCompat.getFont(this, R.font.amiri_regular) ?: Typeface.SERIF
        "naskh" -> androidx.core.content.res.ResourcesCompat.getFont(this, R.font.noto_naskh_arabic_regular) ?: Typeface.SERIF
        "kufi" -> androidx.core.content.res.ResourcesCompat.getFont(this, R.font.noto_kufi_arabic_regular) ?: Typeface.SANS_SERIF
        "sans" -> Typeface.create("sans-serif", Typeface.NORMAL)
        else -> androidx.core.content.res.ResourcesCompat.getFont(this, R.font.amiri_regular) ?: Typeface.SERIF
    }

    private fun updateFavoriteIcon() {
        binding.favoriteButton.setImageResource(if (prefs.isFavorite(this, storyId)) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline)
    }

    private fun openSearch() {
        binding.searchPanel.visibility = View.VISIBLE
        binding.storyScroll.setPadding(binding.storyScroll.paddingLeft, dp(24), binding.storyScroll.paddingRight, dp(48))
        binding.searchInput.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(binding.searchInput, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun closeSearch() {
        binding.searchPanel.visibility = View.GONE
        binding.searchInput.text.clear()
        clearSearchHighlights()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(binding.searchInput.windowToken, 0)
    }

    private fun updateSearchResults() {
        val query = binding.searchInput.text?.toString()?.trim().orEmpty()
        clearSearchHighlights()
        searchMatches.clear()
        searchIndex = 0
        if (query.isEmpty()) { binding.searchCounter.text = "0 من 0"; applyBookmarkHighlights(); return }

        val source = story.content
        var from = 0
        while (from <= source.length - query.length) {
            val at = source.indexOf(query, from, ignoreCase = true)
            if (at < 0) break
            searchMatches.add(at)
            from = at + query.length.coerceAtLeast(1)
        }
        binding.searchCounter.text = if (searchMatches.isEmpty()) "0 من 0" else "1 من ${searchMatches.size}"
        applySearchSpans(query)
        if (searchMatches.isNotEmpty()) scrollToMatch(0)
    }

    private fun applySearchSpans(query: String) {
        val span = SpannableString(story.content)
        searchMatches.forEachIndexed { index, start ->
            val end = (start + query.length).coerceAtMost(story.content.length)
            span.setSpan(BackgroundColorSpan(if (index == searchIndex) Color.parseColor("#8F82FF") else Color.parseColor("#514A6C")), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            span.setSpan(ForegroundColorSpan(if (index == searchIndex) Color.WHITE else Color.parseColor("#E9E5F0")), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        binding.storyText.text = span
        applySavedSettings()
        applyBookmarkHighlights()
    }

    private fun clearSearchHighlights() {
        val current = binding.storyText.text.toString()
        binding.storyText.text = SpannableString(current)
        applySavedSettings()
        applyBookmarkHighlights()
    }

    private fun moveSearch(delta: Int) {
        if (searchMatches.isEmpty()) return
        searchIndex = (searchIndex + delta + searchMatches.size) % searchMatches.size
        binding.searchCounter.text = "${searchIndex + 1} من ${searchMatches.size}"
        applySearchSpans(binding.searchInput.text.toString().trim())
        scrollToMatch(searchIndex)
    }

    private fun scrollToMatch(index: Int) {
        val offset = searchMatches.getOrNull(index) ?: return
        scrollToOffset(offset)
    }

    private fun shareStory() {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "${story.title}\n\n${story.content}")
        }, "مشاركة القصة"))
    }

    private fun copyStory() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(story.title, story.content))
        Toast.makeText(this, "تم نسخ القصة", Toast.LENGTH_SHORT).show()
    }

    private fun openRatingPanel() {
        // يظل التقييم مفتوحًا حتى يضغط المستخدم X أو يغادر صفحة القراءة.
        binding.commentsPanel.visibility = View.GONE
        binding.ratingPanel.visibility = View.VISIBLE
        renderRatingChoices()
        scrollToViewIfNeeded(binding.ratingPanel)
    }

    private fun closeRatingPanel() {
        binding.ratingPanel.visibility = View.GONE
    }

    private fun renderRatingChoices() {
        binding.ratingChoices.removeAllViews()
        if (prefs.hasRated(this, storyId)) {
            binding.ratingStatus.text = "تم تسجيل تقييمك: ${prefs.getMyRating(this, storyId)}/10"
            return
        }
        binding.ratingStatus.text = "اختر تقييمًا مرة واحدة. لا يمكن تغييره لاحقًا."
        for (value in 1..10) {
            val b = TextView(this).apply {
                text = value.toString()
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(currentText())
                background = getDrawable(R.drawable.bg_reader_choice_selected)
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setOnClickListener {
                    prefs.queueRating(this@StoryActivity, storyId, value)
                    renderRatingChoices()
                    Toast.makeText(this@StoryActivity, "تم حفظ تقييمك", Toast.LENGTH_SHORT).show()
                }
            }
            binding.ratingChoices.addView(b, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(4); marginEnd = dp(4) })
        }
    }

    private fun renderRatingState() = renderRatingChoices()

    private fun openCommentsPanel() {
        // تظل التعليقات مفتوحة حتى يضغط المستخدم X أو يغادر صفحة القراءة.
        binding.ratingPanel.visibility = View.GONE
        binding.commentsPanel.visibility = View.VISIBLE
        renderComments()
        scrollToViewIfNeeded(binding.commentsPanel)
    }

    private fun closeCommentsPanel() {
        binding.commentsPanel.visibility = View.GONE
    }

    private fun renderComments() {
        binding.commentsList.removeAllViews()
        val comments = prefs.getComments(this, storyId)
        if (comments.isEmpty()) {
            binding.commentsTitle.text = "التعليقات — لا توجد تعليقات بعد"
            return
        }
        binding.commentsTitle.text = "التعليقات (${comments.size})"
        comments.forEach { comment ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); background = getDrawable(R.drawable.bg_reader_panel) }
            row.addView(TextView(this).apply { text = comment.name; textSize = 14f; setTextColor(currentText()); setTypeface(typeface, Typeface.BOLD) })
            row.addView(TextView(this).apply { text = comment.text; textSize = 14f; setTextColor(currentText()); setPadding(0, dp(4), 0, 0) })
            row.addView(TextView(this).apply { text = comment.time; textSize = 11f; setTextColor(currentMuted()); setPadding(0, dp(4), 0, 0) })
            binding.commentsList.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun submitComment() {
        val text = binding.commentInput.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) return
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        prefs.addComment(this, storyId, text, time)
        binding.commentInput.text.clear()
        renderComments()
        Toast.makeText(this, "تم حفظ التعليق", Toast.LENGTH_SHORT).show()
    }

    private fun switchStory(direction: Int) {
        val next = StoryRepository.adjacentStoryInCategory(storyId, direction)
        if (next == null) {
            Toast.makeText(this, if (direction < 0) "هذه أول قصة في الفرع" else "هذه آخر قصة في الفرع", Toast.LENGTH_SHORT).show()
            return
        }
        loadStory(next, true)
    }

    private fun updateNavButtons() {
        binding.previousButton.isEnabled = StoryRepository.adjacentStoryInCategory(storyId, -1) != null
        binding.nextButton.isEnabled = StoryRepository.adjacentStoryInCategory(storyId, 1) != null
        binding.previousButton.alpha = if (binding.previousButton.isEnabled) 1f else 0.45f
        binding.nextButton.alpha = if (binding.nextButton.isEnabled) 1f else 0.45f
    }

    private fun showModePopup(anchor: View) {
        val box = popupBox()
        addPopupTitle(box, "وضع القراءة")
        listChoice(box, "النهاري", { setMode("day"); box.tagPopup.dismiss() })
        listChoice(box, "الليلي", { setMode("night"); box.tagPopup.dismiss() })
        showPopup(box, anchor)
    }

    private fun setMode(newMode: String) {
        mode = if (newMode == "day") "day" else "night"
        applyTheme()
    }

    private fun showReaderSettings(anchor: View) {
        val box = popupBox()
        addPopupTitle(box, "إعدادات القراءة")
        addRangeControl(box, "حجم الخط", 16, 26, prefs.getInt(this, "font_size", 20), 1) { value -> prefs.putInt(this, "font_size", value); renderStoryText() }
        addRangeControl(box, "تباعد الأسطر", 120, 190, (prefs.getFloat(this, "line_spacing", 1.55f) * 100).toInt(), 5) { value -> prefs.putFloat(this, "line_spacing", value / 100f); renderStoryText() }
        addRangeControl(box, "عرض النص", 70, 100, prefs.getInt(this, "text_width", 92), 5) { value -> prefs.putInt(this, "text_width", value); renderStoryText() }

        addPopupTitle(box, "نوع الخط — معاينة")
        listFontChoice(box, "أميري — نص عربي كلاسيكي", "amiri")
        listFontChoice(box, "نسخ — Noto Naskh Arabic", "naskh")
        listFontChoice(box, "كوفي — Noto Kufi Arabic", "kufi")
        listFontChoice(box, "حديث — Sans", "sans")

        addPopupTitle(box, "العلامات المرجعية")
        val bookmarks = prefs.getBookmarks(this, storyId)
        if (bookmarks.isEmpty()) listChoice(box, "لا توجد علامات محفوظة") {}
        bookmarks.forEachIndexed { index, bookmark ->
            listChoice(box, "${index + 1}. ${bookmark.label}") {
                box.tagPopup.dismiss()
                binding.storyText.post { scrollToOffset(bookmark.offset) }
            }
        }
        showPopup(box, anchor)
    }

    private fun showMoreActions(anchor: View) {
        val box = popupBox()
        addPopupTitle(box, "أدوات القصة")
        listChoice(box, "مشاركة القصة") { box.tagPopup.dismiss(); shareStory() }
        listChoice(box, "نسخ القصة") { box.tagPopup.dismiss(); copyStory() }
        listChoice(box, "تقييم القصة") { box.tagPopup.dismiss(); openRatingPanel() }
        listChoice(box, "التعليقات") { box.tagPopup.dismiss(); openCommentsPanel() }
        showPopup(box, anchor)
    }

    private fun scrollToOffset(offset: Int) {
        val layout = binding.storyText.layout ?: return
        val safe = offset.coerceIn(0, binding.storyText.text.length)
        val line = layout.getLineForOffset(safe)
        val y = binding.storyText.top + layout.getLineTop(line) - binding.storyScroll.height / 3
        binding.storyScroll.smoothScrollTo(0, y.coerceAtLeast(0))
    }

    private fun scrollToViewIfNeeded(view: View) {
        view.post { binding.storyScroll.smoothScrollTo(0, view.top.coerceAtLeast(0)) }
    }

    private fun addRangeControl(box: LinearLayout, label: String, min: Int, maxValue: Int, current: Int, step: Int, onChanged: (Int) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(8)) }
        val title = TextView(this).apply { text = "$label: $current"; textSize = 14f; setTextColor(currentText()) }
        val seek = SeekBar(this)
        seek.max = ((maxValue - min) / step).coerceAtLeast(1)
        seek.progress = ((current.coerceIn(min, maxValue) - min) / step).coerceIn(0, seek.max)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = min + progress * step
                title.text = "$label: $value"
                if (fromUser) onChanged(value)
            }
            override fun onStartTrackingTouch(s: SeekBar?) = Unit
            override fun onStopTrackingTouch(s: SeekBar?) = Unit
        })
        row.addView(title); row.addView(seek); box.addView(row)
    }

    private fun listFontChoice(box: LinearLayout, label: String, key: String) {
        val tv = TextView(this).apply {
            text = label + "\nحكاية جميلة للقراءة الطويلة"
            textSize = 16f
            setTextColor(currentText())
            typeface = fontTypeface(key)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { prefs.putString(this@StoryActivity, "font", key); renderStoryText(); Toast.makeText(this@StoryActivity, "تم تطبيق الخط", Toast.LENGTH_SHORT).show() }
        }
        box.addView(tv)
    }

    private fun addPopupTitle(box: LinearLayout, text: String) {
        box.addView(TextView(this).apply { this.text = text; textSize = 14f; setTextColor(currentMuted()); setPadding(dp(4), dp(10), dp(4), dp(6)) })
    }

    private fun listChoice(box: LinearLayout, text: String, action: () -> Unit) {
        box.addView(TextView(this).apply { this.text = text; textSize = 15f; setTextColor(currentText()); setPadding(dp(12), dp(12), dp(12), dp(12)); setOnClickListener { action() } })
    }

    private class PopupBox(context: Context) : LinearLayout(context) { lateinit var tagPopup: PopupWindow }

    private fun popupBox() = PopupBox(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = panelDrawable()
    }

    private class CappedScrollView(context: Context, private val maxHeightPx: Int) : android.widget.ScrollView(context) {
        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val cappedHeightSpec = MeasureSpec.makeMeasureSpec(maxHeightPx, MeasureSpec.AT_MOST)
            super.onMeasure(widthMeasureSpec, cappedHeightSpec)
        }
    }

    private fun showPopup(box: PopupBox, anchor: View) {
        val maxHeight = (resources.displayMetrics.heightPixels * 0.72f).toInt()
        val scroll = CappedScrollView(this, maxHeight).apply { addView(box) }
        val popup = PopupWindow(scroll, dp(320), android.view.ViewGroup.LayoutParams.WRAP_CONTENT, true)
        box.tagPopup = popup
        popup.setBackgroundDrawable(panelDrawable())
        popup.elevation = dp(10).toFloat()
        popup.isOutsideTouchable = true

        val oldEnd = binding.storyScroll.paddingEnd
        binding.storyScroll.setPadding(binding.storyScroll.paddingLeft, binding.storyScroll.paddingTop, dp(340), binding.storyScroll.paddingBottom)
        popup.setOnDismissListener { binding.storyScroll.setPadding(binding.storyScroll.paddingLeft, binding.storyScroll.paddingTop, oldEnd, binding.storyScroll.paddingBottom) }
        popup.showAtLocation(binding.readerRoot, Gravity.TOP or Gravity.END, dp(8), dp(72))
    }

    private fun applyBookmarkHighlights() {
        val editable = binding.storyText.text as? SpannableString ?: SpannableString(binding.storyText.text)
        val bookmarks = prefs.getBookmarks(this, storyId)
        bookmarks.forEach { bookmark ->
            val start = bookmark.offset.coerceIn(0, editable.length)
            val length = bookmark.selectedText.length
            val end = (start + length).coerceAtMost(editable.length)
            if (end > start) {
                val bg = if (mode == "night") Color.parseColor("#D9A300") else Color.parseColor("#E44B45")
                val fg = if (mode == "night") Color.parseColor("#241E0A") else Color.WHITE
                editable.setSpan(BackgroundColorSpan(bg), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                editable.setSpan(ForegroundColorSpan(fg), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        binding.storyText.text = editable
        applySavedSettings()
    }

    private fun toggleChrome() {
        if (chromeVisible) hideChrome() else showChrome()
    }

    private fun hideChrome() {
        chromeVisible = false
        binding.topBar.visibility = View.GONE
        binding.sideActions.visibility = View.GONE
        binding.moreButton.visibility = View.GONE
        binding.bottomBar.visibility = View.GONE
        binding.readingModeButton.visibility = View.GONE
        binding.settingsButton.visibility = View.GONE
        binding.searchPanel.visibility = View.GONE
        binding.storyScroll.layoutParams = (binding.storyScroll.layoutParams as android.widget.FrameLayout.LayoutParams).also { it.topMargin = 0; it.bottomMargin = 0 }
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    private fun showChrome() {
        chromeVisible = true
        binding.topBar.visibility = View.VISIBLE
        binding.sideActions.visibility = View.GONE
        binding.moreButton.visibility = View.VISIBLE
        binding.bottomBar.visibility = View.VISIBLE
        binding.readingModeButton.visibility = View.VISIBLE
        binding.settingsButton.visibility = View.VISIBLE
        binding.storyScroll.layoutParams = (binding.storyScroll.layoutParams as android.widget.FrameLayout.LayoutParams).also { it.topMargin = dp(70); it.bottomMargin = dp(76) }
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    private fun applyTheme() {
        val day = mode == "day"
        val bg = if (day) Color.parseColor("#F5F1E8") else Color.parseColor("#101114")
        val bar = if (day) Color.parseColor("#FFFDF8") else Color.parseColor("#171920")
        val text = if (day) Color.parseColor("#25242A") else Color.parseColor("#ECEBF0")
        val muted = if (day) Color.parseColor("#62636B") else Color.parseColor("#A5A6AF")
        val accent = if (day) Color.parseColor("#5E54C9") else Color.parseColor("#B7A7FF")
        val panel = if (day) Color.parseColor("#FFFFFF") else Color.parseColor("#1B1E27")
        val button = if (day) Color.parseColor("#F0ECE4") else Color.parseColor("#20232B")
        val pressed = if (day) Color.parseColor("#E4DED3") else Color.parseColor("#30333D")

        binding.readerRoot.setBackgroundColor(bg)
        binding.storyScroll.setBackgroundColor(bg)
        binding.topBar.setBackgroundColor(bar)
        binding.bottomBar.setBackgroundColor(bar)
        binding.ratingPanel.background = panelDrawable()
        binding.commentsPanel.background = panelDrawable()
        binding.searchPanel.background = panelDrawable()
        listOf(
            binding.backButton, binding.favoriteButton, binding.searchButton,
            binding.searchPrev, binding.searchNext, binding.searchClose,
            binding.moreButton, binding.readingModeButton, binding.settingsButton,
            binding.ratingClose, binding.commentsClose, binding.commentSend
        ).forEach { it.background = buttonDrawable(button, pressed, 14f) }
        binding.previousButton.background = buttonDrawable(button, pressed, 16f)
        binding.nextButton.background = buttonDrawable(if (day) Color.parseColor("#7357C8") else Color.parseColor("#6B5BC7"), if (day) Color.parseColor("#6247B2") else Color.parseColor("#5B4CAF"), 16f)
        binding.storyText.setTextColor(text)
        binding.storyTitle.setTextColor(text)
        binding.topTitle.setTextColor(text)
        binding.storyCategory.setTextColor(accent)
        binding.storyRating.setTextColor(if (day) Color.parseColor("#9A7200") else Color.parseColor("#E8BD55"))
        binding.progressText.setTextColor(muted)
        binding.previousButton.setTextColor(text)
        binding.nextButton.setTextColor(text)
        binding.previousButton.compoundDrawableTintList = android.content.res.ColorStateList.valueOf(text)
        binding.nextButton.compoundDrawableTintList = android.content.res.ColorStateList.valueOf(text)
        binding.readingModeButton.imageTintList = android.content.res.ColorStateList.valueOf(accent)
        binding.settingsButton.imageTintList = android.content.res.ColorStateList.valueOf(accent)
        binding.moreButton.imageTintList = android.content.res.ColorStateList.valueOf(text)
        binding.backButton.imageTintList = android.content.res.ColorStateList.valueOf(text)
        binding.favoriteButton.imageTintList = android.content.res.ColorStateList.valueOf(text)
        binding.searchButton.imageTintList = android.content.res.ColorStateList.valueOf(text)
        binding.searchPrev.imageTintList = android.content.res.ColorStateList.valueOf(text)
        binding.searchNext.imageTintList = android.content.res.ColorStateList.valueOf(text)
        binding.searchClose.imageTintList = android.content.res.ColorStateList.valueOf(text)
        binding.searchCounter.setTextColor(muted)
        binding.searchInput.setTextColor(text)
        binding.searchInput.setHintTextColor(muted)
        window.statusBarColor = if (day) Color.parseColor("#6D5BD0") else Color.parseColor("#111218")
        window.navigationBarColor = if (day) Color.parseColor("#111218") else Color.parseColor("#0B0C10")
        renderStoryTextPreservingSearch()
    }

    private fun renderStoryTextPreservingSearch() {
        val query = binding.searchInput.text?.toString()?.trim().orEmpty()
        if (query.isEmpty()) {
            val base = SpannableString(story.content)
            binding.storyText.text = base
            applySavedSettings()
            applyBookmarkHighlights()
        } else updateSearchResults()
    }

    private fun panelDrawable(): GradientDrawable = GradientDrawable().apply {
        setColor(if (mode == "day") Color.parseColor("#FFFFFF") else Color.parseColor("#1B1E27"))
        setStroke(dp(1), if (mode == "day") Color.parseColor("#DDD8CE") else Color.parseColor("#353945"))
        cornerRadius = dp(18).toFloat()
    }

    private fun buttonDrawable(normal: Int, pressed: Int, radiusDp: Float): StateListDrawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), GradientDrawable().apply { setColor(pressed); cornerRadius = dp(radiusDp.toInt()).toFloat() })
        addState(intArrayOf(), GradientDrawable().apply { setColor(normal); cornerRadius = dp(radiusDp.toInt()).toFloat() })
    }

    private fun currentText(): Int = if (mode == "day") Color.parseColor("#25242A") else Color.parseColor("#ECEBF0")
    private fun currentMuted(): Int = if (mode == "day") Color.parseColor("#62636B") else Color.parseColor("#A5A6AF")

    private fun restorePosition() {
        if (!prefs.isSavePositionEnabled(this)) { updateNavButtons(); return }
        binding.storyScroll.post {
            suppressScrollSave = true
            binding.storyScroll.scrollTo(0, prefs.getPosition(this, storyId).coerceAtLeast(0))
            binding.storyScroll.post { suppressScrollSave = false }
        }
    }

    private fun clearSearchForNewStory() {
        searchMatches.clear()
        searchIndex = 0
        binding.searchInput.setText("")
        binding.searchCounter.text = "0 من 0"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onPause() {
        if (prefs.isSavePositionEnabled(this)) prefs.savePosition(this, storyId, binding.storyScroll.scrollY)
        super.onPause()
    }

    override fun onDestroy() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        super.onDestroy()
    }
}
