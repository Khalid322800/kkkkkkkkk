package com.khalid.hikaya

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.khalid.hikaya.databinding.ActivityUserSetupBinding

class UserSetupActivity : AppCompatActivity() {
    private lateinit var binding: ActivityUserSetupBinding
    private var generatedId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val existing = UserManager.get(this)
        if (existing != null) {
            generatedId = existing.userId
            binding.userIdText.text = existing.userId
            binding.usernameInput.setText(existing.username)
        } else {
            // Generate the installation ID immediately, but only persist it after
            // the user confirms the username.
            generatedId = UserManager.generateId()
            binding.userIdText.text = generatedId
        }

        binding.copyIdButton.setOnClickListener {
            val id = generatedId ?: return@setOnClickListener
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Hikaya ID", id))
            Toast.makeText(this, "تم نسخ الآيدي", Toast.LENGTH_SHORT).show()
        }

        binding.continueButton.setOnClickListener {
            val name = binding.usernameInput.text?.toString()?.trim().orEmpty()
            if (name.isBlank()) {
                binding.usernameInput.error = "اكتب اسم المستخدم"
                return@setOnClickListener
            }
            val id = generatedId ?: return@setOnClickListener
            val saved = UserManager.get(this)
            if (saved == null) {
                // Keep the generated ID instead of generating a second one.
                UserManager.createWithId(this, id, name)
            } else {
                UserManager.updateUsername(this, name)
            }
            SyncManager.requestSync(this)
            finish()
        }
    }
}
