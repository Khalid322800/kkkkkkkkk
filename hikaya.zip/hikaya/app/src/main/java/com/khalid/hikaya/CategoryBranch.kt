package com.khalid.hikaya

data class CategoryBranch(
    val id: String = "",                    // معرّف ثابت ومستقل عن الاسم
    val name: String = "",                  // اسم القسم أو الفرع
    val description: String = "",           // وصف تفاصل القسم يظهر للمستخدم
    val icon: String = "",                  // أيقونة القسم أو رابطها
    val parentId: String? = null,           // المعرّف الأب (إذا كان فرعاً يتبع لقسم رئيسي، أو null إذا كان قسماً رئيسياً)
    val order: Int = 0,                     // ترتيب الظهور في الواجهة
    val isActive: Boolean = true            // حالة التفعيل أو الإخفاء
) {
    // دالة لتحويل البيانات إلى خريطة (Map) لحفظها بسهولة في Firebase Firestore
    fun toMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "name" to name,
            "description" to description,
            "icon" to icon,
            "parentId" to parentId,
            "order" to order,
            "isActive" to isActive
        )
    }
}
