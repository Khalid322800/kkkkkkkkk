package com.khalid.hikaya

import android.content.Context

/**
 * Reader-side bridge to the automatic offline-first sync system.
 */
object StoryReaderSync {
    fun pendingRatingCount(context: Context): Int =
        StoryReaderStore.pendingRatingIds(context).size

    fun pendingCommentCount(context: Context): Int =
        StoryReaderStore.pendingCommentIds(context).size

    fun onConnectivityRestored(context: Context) {
        SyncManager.requestSync(context)
    }
}
