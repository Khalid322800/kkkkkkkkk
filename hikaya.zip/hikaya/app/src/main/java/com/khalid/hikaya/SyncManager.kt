package com.khalid.hikaya

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

/**
 * Central entry point for offline-first synchronization.
 *
 * Local changes are stored first. WorkManager starts SyncWorker automatically
 * whenever a network connection becomes available. The real API endpoint can
 * be connected later without changing the UI or local data model.
 */
object SyncManager {
    private const val UNIQUE_WORK = "hikaya_auto_sync"

    fun requestSync(context: Context) {
        if (!UserManager.isConfigured(context)) return
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            UNIQUE_WORK,
            ExistingWorkPolicy.KEEP,
            request
        )
    }
}
