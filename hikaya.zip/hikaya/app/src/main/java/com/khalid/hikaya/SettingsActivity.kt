package com.khalid.hikaya

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.khalid.hikaya.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backButton.setOnClickListener { finish() }

        UserManager.get(this)?.let { user ->
            binding.userNameText.text = "اسم المستخدم: ${user.username}"
            binding.userIdText.text = "الآيدي: ${user.userId}"
        }

        binding.savePositionSwitch.isChecked = StoryReaderStore.isSavePositionEnabled(this)
        binding.savePositionSwitch.setOnCheckedChangeListener { _, enabled ->
            StoryReaderStore.setSavePositionEnabled(this, enabled)
        }

        binding.themeSwitch.isChecked = ThemeManager.isDark(this)
        binding.themeSwitch.setOnCheckedChangeListener { _, enabled ->
            ThemeManager.setDark(this, enabled)
        }

        binding.favoritesRow.setOnClickListener {
            startActivity(Intent(this, FavoritesActivity::class.java))
        }
        binding.contactRow.setOnClickListener {
            startActivity(Intent(this, ContactActivity::class.java))
        }
        binding.aboutRow.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }
    }
}
