package com.khalid.hikaya

// متغيرات ودوال عامة (Top-level) ليستطيع أي نشاط الوصول إليها مباشرة
val allStories: List<Story> = listOf(
    Story(
        id = "1",
        title = "قصة الصبر والظفر",
        content = "محتوى القصة التجريبي...",
        description = "وصف مختصر للقصة",
        category = "cat_1",
        imageUrl = "",
        rating = 5.0f,
        views = 100,
        duration = 5,
        timestamp = System.currentTimeMillis()
    )
)

fun getMainSection(type: String): MainSection {
    return MainSection(
        id = type,
        title = if (type == "islam") "القسم الإسلامي" else "القسم العام",
        description = "وصف القسم الرئيسي",
        categories = listOf(
            StoryCategory(
                id = "cat_1",
                title = "قصص ومواعظ",
                description = "وصف التصنيف الفرعي",
                stories = allStories
            )
        )
    )
}

fun findCategory(categoryId: String): StoryCategory {
    return StoryCategory(
        id = categoryId,
        title = "قسم القصص",
        description = "وصف القسم",
        stories = allStories
    )
}

fun findStory(storyId: String): Story {
    return allStories.find { it.id == storyId } ?: allStories.first()
}

fun adjacentStoryInCategory(currentStoryId: String, categoryId: String, next: Boolean): Story? {
    val list = allStories.filter { categoryId.isEmpty() || it.category == categoryId }
    val index = list.indexOfFirst { it.id == currentStoryId }
    if (index == -1) return list.firstOrNull()
    
    val targetIndex = if (next) index + 1 else index - 1
    return if (targetIndex in list.indices) list[targetIndex] else null
}

// الكائن الاحتياطي لضمان توافق أي استدعاء قديم عبر HikayaDataStore
object HikayaDataStore {
    val allStories = com.khalid.hikaya.allStories
    fun getMainSection(type: String) = com.khalid.hikaya.getMainSection(type)
    fun findCategory(categoryId: String) = com.khalid.hikaya.findCategory(categoryId)
    fun findStory(storyId: String) = com.khalid.hikaya.findStory(storyId)
    fun adjacentStoryInCategory(currentStoryId: String, categoryId: String, next: Boolean) = 
        com.khalid.hikaya.adjacentStoryInCategory(currentStoryId, categoryId, next)
}
