package com.khalid.hikaya

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore

class AdminUsersActivity : AppCompatActivity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val roles = arrayOf("Super Admin", "Content Manager", "Moderator", "Viewer")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val root = AdminUi.root(this)
        root.addView(AdminUi.title(this, "المستخدمون والصلاحيات", "إدارة الأدوار المحفوظة في Firestore. تعيين Custom Claims يتم عبر الخادم الآمن."))
        status = TextView(this).apply { setTextColor(AdminUi.MUTED); textSize = 13f }
        root.addView(status)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list, LinearLayout.LayoutParams(-1, -2).apply { topMargin = AdminUi.dp(this@AdminUsersActivity, 12) })
        scroll.addView(root); setContentView(scroll)
        load()
    }

    private fun load() {
        status.text = "جارٍ تحميل المستخدمين…"
        db.collection("admin_users").get().addOnSuccessListener { snapshot ->
            list.removeAllViews()
            snapshot.documents.forEach { addUser(it) }
            status.text = if (snapshot.isEmpty) "لا يوجد مستخدمون إداريون مسجلون." else "عدد الحسابات: ${snapshot.size()}"
        }.addOnFailureListener { status.text = "تعذر تحميل المستخدمين: ${it.localizedMessage}" }
    }

    private fun addUser(doc: DocumentSnapshot) {
        val card = AdminUi.card(this)
        val email = doc.getString("email") ?: doc.id
        val role = doc.getString("role") ?: "Viewer"
        card.addView(TextView(this).apply { text = email; textSize = 16f; setTextColor(AdminUi.NAVY); setTypeface(null, 1) })
        card.addView(TextView(this).apply { text = "الدور الحالي: $role"; textSize = 13f; setTextColor(AdminUi.MUTED); setPadding(0, 5, 0, 8) })
        val edit = AdminUi.button(this, "تغيير الدور", false)
        edit.setOnClickListener { chooseRole(doc) }
        card.addView(edit)
        list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = AdminUi.dp(this@AdminUsersActivity, 10) })
    }

    private fun chooseRole(doc: DocumentSnapshot) {
        AlertDialog.Builder(this).setTitle("اختر الدور").setItems(roles) { _, index ->
            db.collection("admin_users").document(doc.id).update("role", roles[index], "updatedAt", System.currentTimeMillis())
                .addOnSuccessListener { AuditLogger.log(this, "تغيير دور مستخدم", doc.id); load() }
                .addOnFailureListener { status.text = "تعذر تحديث الدور: ${it.localizedMessage}" }
        }.show()
    }
}
