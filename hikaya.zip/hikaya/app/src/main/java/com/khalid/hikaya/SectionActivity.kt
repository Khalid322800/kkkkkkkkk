package com.khalid.hikaya

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.khalid.hikaya.databinding.ActivitySectionBinding

class SectionActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_SECTION_TYPE = "section_type"
    }

    private lateinit var binding: ActivitySectionBinding
    private lateinit var section: MainSection
    private lateinit var categoryAdapter: CategoryAdapter
    private var storyAdapter: StoryAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySectionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val type = intent.getStringExtra(EXTRA_SECTION_TYPE) ?: "islam"
        section = StoryRepository.getMainSection(type)

        binding.title.text = section.title
        binding.description.text = section.description
        binding.backButton.setOnClickListener { finish() }

        binding.categoryList.layoutManager = LinearLayoutManager(this)
        categoryAdapter = CategoryAdapter(section.categories) { category ->
            startActivity(
                Intent(this, CategoryActivity::class.java)
                    .putExtra(CategoryActivity.EXTRA_CATEGORY_ID, category.id)
            )
        }
        binding.categoryList.adapter = categoryAdapter

        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterStories(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })

        binding.clearSearch.setOnClickListener {
            binding.searchInput.text?.clear()
            binding.searchInput.requestFocus()
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(binding.searchInput, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun filterStories(query: String) {
        val cleanQuery = query.trim()

        if (cleanQuery.isEmpty()) {
            binding.categoryList.visibility = View.VISIBLE
            binding.searchResultsTitle.visibility = View.GONE
            binding.storyList.visibility = View.GONE
            binding.emptySearch.visibility = View.GONE
            binding.clearSearch.visibility = View.GONE
            return
        }

        val results = section.categories
            .flatMap { it.stories }
            .filter { story ->
                story.title.contains(cleanQuery, ignoreCase = true) ||
                    story.description.contains(cleanQuery, ignoreCase = true) ||
                    story.category.contains(cleanQuery, ignoreCase = true)
            }

        binding.categoryList.visibility = View.GONE
        binding.searchResultsTitle.visibility = View.VISIBLE
        binding.storyList.visibility = if (results.isEmpty()) View.GONE else View.VISIBLE
        binding.emptySearch.visibility = if (results.isEmpty()) View.VISIBLE else View.GONE
        binding.clearSearch.visibility = View.VISIBLE
        binding.searchResultsTitle.text = "نتائج البحث (${results.size})"

        storyAdapter = StoryAdapter(results) { story ->
            startActivity(
                Intent(this, StoryActivity::class.java)
                    .putExtra(StoryActivity.EXTRA_STORY_ID, story.id)
            )
        }
        binding.storyList.layoutManager = LinearLayoutManager(this)
        binding.storyList.adapter = storyAdapter
    }
}
