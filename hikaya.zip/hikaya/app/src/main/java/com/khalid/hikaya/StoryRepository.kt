
package com.khalid.hikaya

import android.content.Context
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.Source

class StoryRepository(private val context: Context) {

    private val db: FirebaseFirestore =
        FirebaseFirestore.getInstance()

    init {
        // إعداد التخزين المحلي الدائم في Firestore.
        // الأفضل ضبط هذا الإعداد مرة واحدة قبل أول استخدام لقاعدة البيانات.
        try {
            val settings = FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(true)
                .build()

            db.firestoreSettings = settings
        } catch (_: Exception) {
            // قد يكون الإعداد قد تم تطبيقه مسبقاً.
        }
    }

    /**
     * جلب القصص من Firestore.
     * عند تعذر الجلب من المصدر الافتراضي، تتم محاولة قراءة الكاش المحلي.
     */
    fun fetchStories(
        onSuccess: (List<Map<String, Any>>) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        db.collection("stories")
            .whereEqualTo("isPublished", true)
            .get(Source.DEFAULT)
            .addOnSuccessListener { result ->
                val storiesList = result.documents.map { document ->
                    document.data.orEmpty().toMutableMap().apply {
                        put("id", document.id)
                    }
                }

                onSuccess(storiesList)
            }
            .addOnFailureListener {
                db.collection("stories")
                    .whereEqualTo("isPublished", true)
                    .get(Source.CACHE)
                    .addOnSuccessListener { cachedResult ->
                        val cachedList =
                            cachedResult.documents.map { document ->
                                document.data.orEmpty()
                                    .toMutableMap()
                                    .apply {
                                        put("id", document.id)
                                    }
                            }

                        onSuccess(cachedList)
                    }
                    .addOnFailureListener { cacheException ->
                        onFailure(cacheException)
                    }
            }
    }

    companion object {

        /**
         * هذه الدالة حالياً لا تجلب بيانات من Firestore؛
         * إنها قائمة فارغة إلى أن يتم ربطها بمصدر القصص الفعلي.
         */
        fun allStories(): List<Story> = emptyList()

        fun getMainSection(type: String): MainSection {
            return MainSection(id = type)
        }

        fun findCategory(categoryId: String?): StoryCategory? {
            return null
        }

        fun findStory(storyId: Int): Story? {
            return null
        }

        fun findStory(storyId: String?): Story? {
            return null
        }

        fun adjacentStoryInCategory(
            currentStoryId: Int,
            direction: Int
        ): Story? {
            return null
        }
    }
}
