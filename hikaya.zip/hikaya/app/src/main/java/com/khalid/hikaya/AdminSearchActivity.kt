package com.khalid.hikaya

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore

class AdminSearchActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private var query = ""

    private data class Result(
        val type: Type,
        val title: String,
        val subtitle: String,
        val target: Class<*>
    )

    private enum class Type { STORY, CATEGORY, COMMENT, REPORT, USER }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = AdminUi.root(this)
        root.addView(AdminUi.title(this, "البحث الشامل", "ابحث في محتوى لوحة الإدارة من مكان واحد."))
        input = AdminUi.search(this, "قصة، قسم، تعليق، بلاغ أو مستخدم...")
        input.setText(intent.getStringExtra(EXTRA_QUERY).orEmpty())
        root.addView(input, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 50)).apply { topMargin = AdminUi.dp(this@AdminSearchActivity, 18) })
        status = TextView(this).apply { setTextColor(AdminUi.MUTED); textSize = 13f; setPadding(0, 14, 0, 8) }
        root.addView(status)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s?.toString().orEmpty(); if (query.trim().length >= 2) search() }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        if (input.text.toString().trim().length >= 2) search()
    }

    private fun search() {
        val q = query.trim()
        status.text = "جارٍ البحث في محتوى الإدارة…"
        list.removeAllViews()
        AdminAuth.verifyCurrentAdmin { isAdmin, _ ->
            if (!isAdmin) {
                status.text = "جلسة المدير غير صالحة. سجّل الدخول مجددًا."
                return@verifyCurrentAdmin
            }
            loadAll(q)
        }
    }

    private fun loadAll(q: String) {
        db.collection("stories").get().addOnSuccessListener { stories ->
            db.collection("categories").get().addOnSuccessListener { categories ->
                db.collection("comments").get().addOnSuccessListener { comments ->
                    db.collection("reports").get().addOnSuccessListener { reports ->
                        db.collection("users").get().addOnSuccessListener { users ->
                            val results = buildResults(q, stories.documents, categories.documents, comments.documents, reports.documents, users.documents)
                            render(results)
                        }.addOnFailureListener { render(buildResults(q, stories.documents, categories.documents, comments.documents, reports.documents, emptyList())) }
                    }.addOnFailureListener { render(buildResults(q, stories.documents, categories.documents, comments.documents, emptyList(), emptyList())) }
                }.addOnFailureListener { render(buildResults(q, stories.documents, categories.documents, emptyList(), emptyList(), emptyList())) }
            }.addOnFailureListener { render(buildResults(q, stories.documents, emptyList(), emptyList(), emptyList(), emptyList())) }
        }.addOnFailureListener { status.text = "تعذر البحث في Firebase: ${it.localizedMessage.orEmpty()}" }
    }

    private fun buildResults(q: String, stories: List<DocumentSnapshot>, categories: List<DocumentSnapshot>, comments: List<DocumentSnapshot>, reports: List<DocumentSnapshot>, users: List<DocumentSnapshot>): List<Result> {
        fun matches(vararg values: String) = values.any { it.contains(q, true) }
        val results = mutableListOf<Result>()
        stories.filter { matches(it.getString("title").orEmpty(), it.getString("description").orEmpty(), it.getString("categoryName").orEmpty()) }.forEach {
            results += Result(Type.STORY, it.getString("title").orEmpty().ifBlank { "قصة بدون عنوان" }, "قصة • ${it.getString("categoryName").orEmpty().ifBlank { "قسم غير محدد" }}", ManageStoriesActivity::class.java)
        }
        categories.filter { matches(it.getString("name").orEmpty(), it.getString("description").orEmpty()) }.forEach {
            results += Result(Type.CATEGORY, it.getString("name").orEmpty(), "قسم أو فرع", ManageSectionsActivity::class.java)
        }
        comments.filter { matches(it.getString("username").orEmpty(), it.getString("text").orEmpty(), it.getString("storyId").orEmpty()) }.forEach {
            results += Result(Type.COMMENT, it.getString("username").orEmpty().ifBlank { "تعليق" }, it.getString("text").orEmpty(), ManageCommentsActivity::class.java)
        }
        reports.filter { matches(it.getString("reason").orEmpty(), it.getString("details").orEmpty(), it.getString("storyId").orEmpty()) }.forEach {
            results += Result(Type.REPORT, it.getString("reason").orEmpty().ifBlank { "بلاغ" }, it.getString("details").orEmpty(), ModerationReviewActivity::class.java)
        }
        users.filter { matches(it.getString("username").orEmpty(), it.getString("email").orEmpty(), it.id) }.forEach {
            results += Result(Type.USER, it.getString("username").orEmpty().ifBlank { it.id }, it.getString("email").orEmpty(), ModerationReviewActivity::class.java)
        }
        return results
    }

    private fun render(results: List<Result>) {
        status.text = if (results.isEmpty()) "لا توجد نتائج مطابقة لـ «$query»" else "تم العثور على ${results.size} نتيجة"
        list.removeAllViews()
        if (results.isEmpty()) return
        results.forEach { result ->
            val card = AdminUi.card(this).apply { isClickable = true; isFocusable = true }
            card.addView(TextView(this).apply { text = "${typeLabel(result.type)}  •  ${result.title}"; textSize = 16f; setTextColor(AdminUi.NAVY); setTypeface(null, 1) })
            card.addView(TextView(this).apply { text = result.subtitle; textSize = 12f; setTextColor(AdminUi.MUTED); setPadding(0, 6, 0, 0) })
            card.setOnClickListener { startActivity(android.content.Intent(this, result.target)) }
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
    }

    private fun typeLabel(type: Type) = when (type) { Type.STORY -> "قصة"; Type.CATEGORY -> "قسم"; Type.COMMENT -> "تعليق"; Type.REPORT -> "بلاغ"; Type.USER -> "مستخدم" }

    companion object { const val EXTRA_QUERY = "admin_search_query" }
}
