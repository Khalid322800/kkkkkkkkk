package com.khalid.hikaya

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.View
import kotlin.math.max

class AnalyticsChartView(context: Context) : View(context) {
    data class Point(val label: String, val value: Long)

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var points: List<Point> = emptyList()
    private var emptyMessage = "لا توجد بيانات يومية بعد"

    init {
        minimumHeight = AdminUi.dp(context, 220)
        textPaint.typeface = Typeface.DEFAULT
        setBackgroundColor(0xFFFFFFFF.toInt())
    }

    fun submit(points: List<Point>, emptyMessage: String = "لا توجد بيانات يومية بعد") {
        this.points = points
        this.emptyMessage = emptyMessage
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = AdminUi.dp(context, 34).toFloat()
        val right = width - AdminUi.dp(context, 14).toFloat()
        val top = AdminUi.dp(context, 18).toFloat()
        val bottom = height - AdminUi.dp(context, 34).toFloat()
        linePaint.color = 0xFFE8E3DA.toInt()
        linePaint.strokeWidth = AdminUi.dp(context, 1).toFloat()
        for (i in 0..3) {
            val y = top + (bottom - top) * i / 3f
            canvas.drawLine(left, y, right, y, linePaint)
        }
        if (points.isEmpty()) {
            textPaint.color = AdminUi.MUTED
            textPaint.textSize = AdminUi.dp(context, 13).toFloat()
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText(emptyMessage, width / 2f, (top + bottom) / 2f, textPaint)
            return
        }
        val maxValue = max(1L, points.maxOf { it.value }).toFloat()
        val step = (right - left) / points.size
        val barWidth = (step * 0.56f).coerceAtLeast(AdminUi.dp(context, 8).toFloat())
        val path = Path()
        points.forEachIndexed { index, point ->
            val x = left + step * index + step / 2f
            val y = bottom - (point.value / maxValue) * (bottom - top)
            barPaint.color = if (index % 2 == 0) AdminUi.NAVY else AdminUi.GOLD
            canvas.drawRoundRect(x - barWidth / 2f, y, x + barWidth / 2f, bottom, AdminUi.dp(context, 5).toFloat(), AdminUi.dp(context, 5).toFloat(), barPaint)
            if (points.size <= 14 || index % maxOf(1, points.size / 7) == 0) {
                textPaint.color = AdminUi.MUTED
                textPaint.textSize = AdminUi.dp(context, 9).toFloat()
                textPaint.textAlign = Paint.Align.CENTER
                canvas.drawText(point.label, x, height - AdminUi.dp(context, 12).toFloat(), textPaint)
            }
            path.moveTo(if (index == 0) x else left + step * (index - 1) + step / 2f, if (index == 0) y else bottom - (points[index - 1].value / maxValue) * (bottom - top))
            path.lineTo(x, y)
        }
        linePaint.color = AdminUi.GOLD
        linePaint.style = Paint.Style.STROKE
        linePaint.strokeWidth = AdminUi.dp(context, 2).toFloat()
        canvas.drawPath(path, linePaint)
        linePaint.style = Paint.Style.FILL
    }
}
