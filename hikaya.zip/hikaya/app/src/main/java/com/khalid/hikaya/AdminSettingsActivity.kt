package com.khalid.hikaya

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore

class AdminSettingsActivity : AppCompatActivity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = AdminUi.root(this)
        root.addView(AdminUi.title(this, "إعدادات الإدارة والاتصال", "تحقق من حالة Firebase وتفضيلات لوحة الإدارة."))
        val card = AdminUi.card(this)
        status = TextView(this).apply { text = "لم يتم الاختبار بعد"; setTextColor(AdminUi.MUTED); textSize = 13f }
        card.addView(status)
        val test = AdminUi.button(this, "اختبار الاتصال الآن", true)
        card.addView(test, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 48)).apply { topMargin = AdminUi.dp(this@AdminSettingsActivity, 12) })
        val sync = AdminUi.button(this, "تحديث بيانات لوحة الإدارة", false)
        card.addView(sync, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 48)).apply { topMargin = AdminUi.dp(this@AdminSettingsActivity, 8) })
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = AdminUi.dp(this@AdminSettingsActivity, 20) })
        setContentView(root)
        test.setOnClickListener { testConnection() }
        sync.setOnClickListener { status.text = "افتح لوحة الإدارة واضغط تحديث لإعادة تحميل الإحصائيات." }
    }
    private fun testConnection() {
        status.text = "جارٍ اختبار Firestore وRealtime Database…"
        FirebaseFirestore.getInstance().collection("stories").limit(1).get().addOnSuccessListener {
            FirebaseDatabase.getInstance().reference.child("notifications").limitToFirst(1).get()
                .addOnSuccessListener { status.text = "الاتصال بـ Firestore وRealtime Database يعمل." }
                .addOnFailureListener { status.text = "Firestore يعمل، لكن Realtime Database فشل: ${it.localizedMessage}" }
        }.addOnFailureListener { status.text = "فشل اتصال Firestore: ${it.localizedMessage}" }
    }
}
