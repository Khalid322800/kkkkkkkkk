package com.khalid.hikaya

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore

class ManageSectionsActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var search: EditText
    private var cats = listOf<CategoryBranch>()
    private var storyCounts = emptyMap<String, Int>()
    private var query = ""
    private var showInactive = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = AdminUi.root(this)
        root.addView(AdminUi.title(this, "إدارة الأقسام والفروع", "نظم بنية المكتبة وتابع القصص داخل كل قسم."))

        val add = AdminUi.button(this, "＋ إنشاء قسم رئيسي", true)
        root.addView(add, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 50)).apply {
            topMargin = AdminUi.dp(this@ManageSectionsActivity, 18)
        })

        search = AdminUi.search(this, "ابحث عن قسم أو فرع...")
        root.addView(search, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 50)).apply {
            topMargin = AdminUi.dp(this@ManageSectionsActivity, 12)
        })

        val tools = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val filter = AdminUi.button(this, "الكل")
        val refresh = AdminUi.button(this, "تحديث")
        tools.addView(filter, LinearLayout.LayoutParams(0, AdminUi.dp(this, 46), 1f))
        tools.addView(refresh, LinearLayout.LayoutParams(-2, AdminUi.dp(this, 46)).apply {
            marginStart = AdminUi.dp(this@ManageSectionsActivity, 8)
        })
        root.addView(tools, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = AdminUi.dp(this@ManageSectionsActivity, 10)
        })

        status = TextView(this).apply {
            setTextColor(AdminUi.MUTED)
            textSize = 13f
            setPadding(0, AdminUi.dp(this@ManageSectionsActivity, 14), 0, AdminUi.dp(this@ManageSectionsActivity, 8))
        }
        root.addView(status)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        add.setOnClickListener { showEditor(null) }
        refresh.setOnClickListener { load() }
        filter.setOnClickListener {
            showInactive = !showInactive
            filter.text = if (showInactive) "الكل" else "النشطة فقط"
            render()
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                query = s?.toString().orEmpty()
                render()
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) load()
    }

    private fun load() {
        status.text = "جارٍ تحميل الأقسام وعدد القصص…"
        db.collection("categories").get()
            .addOnSuccessListener { categorySnapshot ->
                cats = categorySnapshot.documents.mapNotNull { toCategory(it) }
                db.collection("stories").get()
                    .addOnSuccessListener { storySnapshot ->
                        storyCounts = storySnapshot.documents
                            .mapNotNull { storyCategoryId(it) }
                            .groupingBy { it }
                            .eachCount()
                        status.text = "${cats.size} قسم • ${storySnapshot.size()} قصة مرتبطة"
                        render()
                    }
                    .addOnFailureListener {
                        storyCounts = emptyMap()
                        status.text = "تم تحميل الأقسام، وتعذر حساب القصص المرتبطة"
                        render()
                    }
            }
            .addOnFailureListener {
                status.text = "تعذر تحميل الأقسام: ${it.localizedMessage.orEmpty()}"
                list.removeAllViews()
            }
    }

    private fun render() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val normalized = query.trim()
        val visible = cats.filter { category ->
            (showInactive || category.isActive) &&
                (normalized.isBlank() || category.name.contains(normalized, true) || category.description.contains(normalized, true))
        }
        if (visible.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (cats.isEmpty()) "لا توجد أقسام بعد" else "لا توجد أقسام مطابقة للبحث أو الفلتر الحالي"
                setTextColor(AdminUi.MUTED)
                textSize = 14f
                setPadding(0, AdminUi.dp(this@ManageSectionsActivity, 18), 0, 0)
            })
            return
        }

        val roots = visible.filter { it.parentId.isNullOrBlank() }.sortedBy { it.order }
        roots.forEach { root -> renderRow(root, 0, visible) }
        val renderedIds = visible.flatMap { descendantsOf(it, visible).map(CategoryBranch::id) }.toSet() + roots.map { it.id }
        visible.filter { it.id !in renderedIds }.sortedBy { it.order }.forEach { renderRow(it, 0, visible) }
    }

    private fun renderRow(category: CategoryBranch, depth: Int, visible: List<CategoryBranch>) {
        val children = visible.filter { it.parentId == category.id }.sortedBy { it.order }
        val storyCount = storyCounts[category.id] ?: 0
        val card = AdminUi.card(this)
        card.setPadding(
            AdminUi.dp(this, 14 + depth * 14),
            AdminUi.dp(this, 14),
            AdminUi.dp(this, 14),
            AdminUi.dp(this, 12)
        )
        card.addView(TextView(this).apply {
            text = "${if (depth == 0) "▣" else "└"}  ${category.name}"
            textSize = if (depth == 0) 17f else 15f
            setTextColor(AdminUi.NAVY)
            setTypeface(null, 1)
        })
        card.addView(TextView(this).apply {
            val state = if (category.isActive) "ظاهر في التطبيق" else "مخفي عن التطبيق"
            text = "${category.description.ifBlank { "بدون وصف" }}  •  $state  •  $storyCount قصة"
            textSize = 12f
            setTextColor(if (category.isActive) AdminUi.MUTED else AdminUi.GOLD)
            setPadding(0, AdminUi.dp(this@ManageSectionsActivity, 6), 0, AdminUi.dp(this@ManageSectionsActivity, 8))
        })

        val actions = LinearLayout(this)
        val edit = AdminUi.button(this, "تعديل")
        val child = AdminUi.button(this, "＋ فرع")
        val more = AdminUi.button(this, "المزيد")
        actions.addView(edit, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(child, LinearLayout.LayoutParams(0, -2, 1f).apply {
            marginStart = AdminUi.dp(this@ManageSectionsActivity, 6)
        })
        actions.addView(more, LinearLayout.LayoutParams(0, -2, 1f).apply {
            marginStart = AdminUi.dp(this@ManageSectionsActivity, 6)
        })
        card.addView(actions)
        edit.setOnClickListener { showEditor(category) }
        child.setOnClickListener { showEditor(null, category.id) }
        more.setOnClickListener { showActions(category) }

        list.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = AdminUi.dp(this@ManageSectionsActivity, 10)
        })
        children.forEach { renderRow(it, depth + 1, visible) }
    }

    private fun showEditor(existing: CategoryBranch?, parentId: String? = null) {
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(AdminUi.dp(this@ManageSectionsActivity, 18), 0, AdminUi.dp(this@ManageSectionsActivity, 18), 0)
        }
        val name = AdminUi.field(this, "اسم القسم أو الفرع", existing?.name.orEmpty())
        val desc = AdminUi.field(this, "الوصف", existing?.description.orEmpty())
        form.addView(name)
        form.addView(desc, marginParams())

        var parent = cats.firstOrNull { it.id == (existing?.parentId ?: parentId) }
        val parentButton = AdminUi.button(this, "الأب: ${parent?.name ?: "قسم رئيسي"}")
        form.addView(parentButton, marginParams())
        parentButton.setOnClickListener { chooseParent(parentButton, parent?.id) { selected -> parent = selected } }

        val active = CheckBox(this).apply {
            text = "إظهار القسم في التطبيق"
            isChecked = existing?.isActive ?: true
            setTextColor(AdminUi.NAVY)
        }
        form.addView(active, marginParams())

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existing == null) if (parent == null) "إنشاء قسم رئيسي" else "إنشاء فرع" else "تعديل القسم")
            .setView(form)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val cleanName = name.text?.toString()?.trim().orEmpty()
                if (cleanName.isBlank()) {
                    Toast.makeText(this, "اكتب اسم القسم أولاً", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (existing != null && parent?.id == existing.id) {
                    Toast.makeText(this, "لا يمكن جعل القسم أبًا لنفسه", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val ref = if (existing == null) db.collection("categories").document() else db.collection("categories").document(existing.id)
                val siblings = cats.filter { (it.parentId ?: "") == (parent?.id ?: "") && it.id != existing?.id }
                val data = mapOf<String, Any?>(
                    "id" to ref.id,
                    "name" to cleanName,
                    "description" to desc.text.toString().trim(),
                    "icon" to (existing?.icon ?: "folder"),
                    "parentId" to parent?.id,
                    "order" to (existing?.order ?: ((siblings.maxOfOrNull { it.order } ?: -1) + 1)),
                    "isActive" to active.isChecked,
                    "updatedAt" to System.currentTimeMillis()
                )
                ref.set(data).addOnSuccessListener {
                    dialog.dismiss()
                    load()
                }.addOnFailureListener {
                    status.text = "تعذر حفظ القسم: ${it.localizedMessage.orEmpty()}"
                }
            }
        }
        dialog.show()
    }

    private fun chooseParent(button: Button, currentId: String?, onSelected: (CategoryBranch?) -> Unit) {
        val options = listOf(CategoryBranch(id = "", name = "قسم رئيسي")) + cats.filter { it.isActive && it.id != currentId }
        AlertDialog.Builder(this)
            .setTitle("اختر القسم الأب")
            .setItems(options.map { it.name }.toTypedArray()) { _, which ->
                val selected = options[which].takeIf { it.id.isNotBlank() }
                button.text = "الأب: ${selected?.name ?: "قسم رئيسي"}"
                onSelected(selected)
            }
            .show()
    }

    private fun showActions(category: CategoryBranch) {
        val toggle = if (category.isActive) "تعطيل القسم" else "إعادة تفعيل القسم"
        val options = arrayOf(toggle, "تحريك للأعلى", "تحريك للأسفل", "حذف القسم")
        AlertDialog.Builder(this)
            .setTitle(category.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> toggleCategory(category)
                    1 -> move(category, -1)
                    2 -> move(category, 1)
                    3 -> deleteCategory(category)
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun toggleCategory(category: CategoryBranch) {
        db.collection("categories").document(category.id)
            .update("isActive", !category.isActive, "updatedAt", System.currentTimeMillis())
            .addOnSuccessListener { load() }
            .addOnFailureListener { status.text = "تعذر تغيير حالة القسم: ${it.localizedMessage.orEmpty()}" }
    }

    private fun move(category: CategoryBranch, direction: Int) {
        val siblings = cats.filter { (it.parentId ?: "") == (category.parentId ?: "") }.sortedBy { it.order }
        val index = siblings.indexOfFirst { it.id == category.id }
        val targetIndex = index + direction
        if (index < 0 || targetIndex !in siblings.indices) return
        val target = siblings[targetIndex]
        val batch = db.batch()
        batch.update(db.collection("categories").document(category.id), "order", target.order)
        batch.update(db.collection("categories").document(target.id), "order", category.order)
        batch.commit().addOnSuccessListener { load() }
            .addOnFailureListener { status.text = "تعذر تغيير الترتيب: ${it.localizedMessage.orEmpty()}" }
    }

    private fun deleteCategory(category: CategoryBranch) {
        val hasChildren = cats.any { it.parentId == category.id }
        val hasStories = (storyCounts[category.id] ?: 0) > 0
        if (hasChildren || hasStories) {
            val reason = when {
                hasChildren && hasStories -> "يحتوي على فروع وقصص"
                hasChildren -> "يحتوي على فروع"
                else -> "يحتوي على قصص"
            }
            AlertDialog.Builder(this)
                .setTitle("لا يمكن حذف القسم")
                .setMessage("هذا القسم $reason. عطّله بدل حذفه، أو انقل العناصر المرتبطة أولاً.")
                .setPositiveButton("حسنًا", null)
                .show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("حذف القسم")
            .setMessage("هل تريد حذف «${category.name}» نهائيًا؟")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حذف") { _, _ ->
                db.collection("categories").document(category.id).delete()
                    .addOnSuccessListener { load() }
                    .addOnFailureListener { status.text = "تعذر حذف القسم: ${it.localizedMessage.orEmpty()}" }
            }
            .show()
    }

    private fun descendantsOf(category: CategoryBranch, visible: List<CategoryBranch>): List<CategoryBranch> =
        visible.filter { it.parentId == category.id }.flatMap { listOf(it) + descendantsOf(it, visible) }

    private fun toCategory(document: DocumentSnapshot): CategoryBranch? {
        val name = document.getString("name")?.trim().orEmpty()
        if (name.isBlank()) return null
        return CategoryBranch(
            id = document.id,
            name = name,
            description = document.getString("description").orEmpty(),
            icon = document.getString("icon") ?: "folder",
            parentId = document.getString("parentId"),
            order = (document.getLong("order") ?: 0L).toInt(),
            isActive = document.getBoolean("isActive") != false
        )
    }

    private fun storyCategoryId(document: DocumentSnapshot): String? =
        (document.getString("categoryId") ?: document.getString("category") ?: document.getString("branch"))?.takeIf { it.isNotBlank() }

    private fun marginParams() = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = AdminUi.dp(this@ManageSectionsActivity, 9)
    }
}
