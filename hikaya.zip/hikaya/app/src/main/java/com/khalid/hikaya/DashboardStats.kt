package com.khalid.hikaya

import com.google.firebase.firestore.DocumentSnapshot
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

data class DashboardStats(
    val stories: Int,
    val categories: Int,
    val users: Int,
    val views: Long,
    val averageRating: Double
) {
    companion object {
        fun fromStories(documents: List<DocumentSnapshot>): DashboardStats {
            val views = documents.sumOf { it.number("views")?.toLong() ?: 0L }
            val ratings = documents.mapNotNull { it.number("rating")?.toDouble() }
            return DashboardStats(
                stories = documents.size,
                categories = 0,
                users = 0,
                views = views,
                averageRating = ratings.average().takeIf { !it.isNaN() } ?: 0.0
            )
        }

        fun formatInteger(value: Long): String =
            DecimalFormat("#,###", DecimalFormatSymbols(Locale.US)).format(value)

        fun formatRating(value: Double): String =
            if (value <= 0.0) "—" else DecimalFormat("0.0", DecimalFormatSymbols(Locale.US)).format(value)
    }
}

private fun DocumentSnapshot.number(field: String): Number? = get(field) as? Number
