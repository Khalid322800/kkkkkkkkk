package com.khalid.hikaya

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class NotificationsActivity : AppCompatActivity() {
    private val ref = FirebaseDatabase.getInstance().reference
    private lateinit var title: EditText
    private lateinit var body: EditText
    private lateinit var story: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = AdminUi.root(this)
        root.addView(AdminUi.title(this, "الإشعارات الحقيقية", "أنشئ طلب Push؛ الإرسال الفعلي يتم عبر Cloud Function آمنة."))
        val card = AdminUi.card(this)
        title = AdminUi.field(this, "عنوان الإشعار")
        body = AdminUi.field(this, "نص الإشعار", multi = true)
        story = AdminUi.field(this, "معرف القصة المرتبطة (اختياري)")
        card.addView(title)
        card.addView(body, LinearLayout.LayoutParams(-1, -2).apply { topMargin = AdminUi.dp(this@NotificationsActivity, 10) })
        card.addView(story, LinearLayout.LayoutParams(-1, -2).apply { topMargin = AdminUi.dp(this@NotificationsActivity, 10) })
        val send = AdminUi.button(this, "إرسال Push وحفظ السجل", true)
        card.addView(send, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 50)).apply { topMargin = AdminUi.dp(this@NotificationsActivity, 14) })
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = AdminUi.dp(this@NotificationsActivity, 22) })
        status = TextView(this).apply { setTextColor(AdminUi.MUTED); textSize = 13f; setPadding(0, 18, 0, 0) }
        root.addView(status)
        setContentView(root)
        send.setOnClickListener { queueNotification() }
    }

    private fun queueNotification() {
        val t = title.text.toString().trim()
        val b = body.text.toString().trim()
        if (t.isBlank() || b.isBlank()) {
            status.text = "اكتب عنوان الإشعار ونصه أولاً"
            return
        }
        val id = ref.child("notifications").push().key ?: System.currentTimeMillis().toString()
        val data = mapOf(
            "id" to id,
            "title" to t,
            "body" to b,
            "storyId" to story.text.toString().trim(),
            "timestamp" to System.currentTimeMillis(),
            "status" to "QUEUED"
        )
        ref.child("notifications").child(id).setValue(data)
            .addOnSuccessListener {
                status.text = "تم إنشاء طلب الإرسال. ستتولى Cloud Function إرسال Push وتحديث الحالة."
                title.text.clear(); body.text.clear(); story.text.clear()
            }
            .addOnFailureListener { status.text = "فشل إنشاء الطلب: ${it.localizedMessage}" }
    }
}
