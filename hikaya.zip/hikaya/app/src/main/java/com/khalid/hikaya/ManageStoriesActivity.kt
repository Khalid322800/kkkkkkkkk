package com.khalid.hikaya

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore

class ManageStoriesActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var filterButton: Button
    private var categories = listOf<CategoryBranch>()
    private var docs = listOf<DocumentSnapshot>()
    private var query = ""
    private var stateFilter = StateFilter.ALL
    private var sortMode = SortMode.NEWEST

    private enum class StateFilter { ALL, PUBLISHED, DRAFTS }
    private enum class SortMode { NEWEST, OLDEST, MOST_READ, TITLE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = AdminUi.root(this)
        root.addView(AdminUi.title(this, "إدارة القصص", "أضف قصصك ونظمها وراجع حالتها من مكان واحد."))

        val add = AdminUi.button(this, "＋ إضافة قصة", true)
        root.addView(add, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 50)).apply {
            topMargin = AdminUi.dp(this@ManageStoriesActivity, 18)
        })

        val search = AdminUi.search(this, "ابحث عن عنوان أو قسم...")
        root.addView(search, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 50)).apply {
            topMargin = AdminUi.dp(this@ManageStoriesActivity, 12)
        })

        val filters = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        filterButton = AdminUi.button(this, "الكل  •  الأحدث")
        val refresh = AdminUi.button(this, "تحديث")
        filters.addView(filterButton, LinearLayout.LayoutParams(0, AdminUi.dp(this, 46), 1f))
        filters.addView(refresh, LinearLayout.LayoutParams(-2, AdminUi.dp(this, 46)).apply {
            marginStart = AdminUi.dp(this@ManageStoriesActivity, 8)
        })
        root.addView(filters, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = AdminUi.dp(this@ManageStoriesActivity, 10)
        })

        status = TextView(this).apply {
            setTextColor(AdminUi.MUTED)
            textSize = 13f
            setPadding(0, AdminUi.dp(this@ManageStoriesActivity, 14), 0, AdminUi.dp(this@ManageStoriesActivity, 8))
        }
        root.addView(status)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        add.setOnClickListener { loadCategories { showEditor(null) } }
        refresh.setOnClickListener { loadCategories { loadStories() } }
        filterButton.setOnClickListener { showFilters() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                query = s?.toString().orEmpty()
                renderFiltered()
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) loadCategories { loadStories() }
    }

    private fun loadCategories(done: () -> Unit) {
        db.collection("categories").get()
            .addOnSuccessListener { snapshot ->
                categories = snapshot.documents.mapNotNull { d ->
                    val name = d.getString("name")?.trim().orEmpty()
                    if (name.isBlank()) return@mapNotNull null
                    CategoryBranch(
                        id = d.id,
                        name = name,
                        description = d.getString("description").orEmpty(),
                        icon = d.getString("icon") ?: "folder",
                        parentId = d.getString("parentId"),
                        order = (d.getLong("order") ?: 0L).toInt(),
                        isActive = d.getBoolean("isActive") != false
                    )
                }.filter { it.isActive }
                done()
            }
            .addOnFailureListener {
                status.text = "تعذر تحميل الأقسام: ${it.localizedMessage.orEmpty()}"
            }
    }

    private fun loadStories() {
        status.text = "جارٍ تحميل القصص…"
        db.collection("stories").get()
            .addOnSuccessListener { snapshot ->
                docs = snapshot.documents
                renderFiltered()
            }
            .addOnFailureListener {
                status.text = "فشل تحميل القصص: ${it.localizedMessage.orEmpty()}"
                list.removeAllViews()
            }
    }

    private fun renderFiltered() {
        if (!::list.isInitialized) return
        val normalized = query.trim()
        val filtered = docs.filter { document ->
            val title = document.getString("title").orEmpty()
            val category = document.getString("categoryName").orEmpty()
            val matchesQuery = normalized.isBlank() ||
                title.contains(normalized, true) || category.contains(normalized, true)
            val published = isPublished(document)
            val matchesState = when (stateFilter) {
                StateFilter.ALL -> true
                StateFilter.PUBLISHED -> published
                StateFilter.DRAFTS -> !published
            }
            matchesQuery && matchesState
        }.let { items ->
            when (sortMode) {
                SortMode.NEWEST -> items.sortedByDescending { timestampOf(it) }
                SortMode.OLDEST -> items.sortedBy { timestampOf(it) }
                SortMode.MOST_READ -> items.sortedByDescending { numberOf(it, "views") }
                SortMode.TITLE -> items.sortedBy { it.getString("title").orEmpty() }
            }
        }

        status.text = "${filtered.size} من ${docs.size} قصة"
        render(filtered)
    }

    private fun render(items: List<DocumentSnapshot>) {
        list.removeAllViews()
        if (items.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (docs.isEmpty()) "لا توجد قصص بعد" else "لا توجد قصص مطابقة للفلاتر الحالية"
                setTextColor(AdminUi.MUTED)
                textSize = 14f
                setPadding(0, AdminUi.dp(this@ManageStoriesActivity, 18), 0, 0)
            })
            return
        }

        items.forEach { document ->
            val title = document.getString("title").orEmpty().ifBlank { "قصة بدون عنوان" }
            val categoryId = document.getString("categoryId") ?: document.getString("category").orEmpty()
            val category = categories.firstOrNull { it.id == categoryId }?.name
                ?: document.getString("categoryName").orEmpty().ifBlank { "قسم غير محدد" }
            val views = numberOf(document, "views")
            val rating = numberOf(document, "rating").toDouble()
            val published = isPublished(document)

            val card = AdminUi.card(this)
            card.addView(TextView(this).apply {
                text = title
                textSize = 17f
                setTextColor(AdminUi.NAVY)
                setTypeface(null, 1)
            })
            card.addView(TextView(this).apply {
                text = "$category  •  $views قراءة  •  ${if (rating > 0) "${"%.1f".format(rating)} ★" else "بدون تقييم"}"
                textSize = 12f
                setTextColor(AdminUi.MUTED)
                setPadding(0, AdminUi.dp(this@ManageStoriesActivity, 6), 0, AdminUi.dp(this@ManageStoriesActivity, 5))
            })
            card.addView(TextView(this).apply {
                text = if (published) "منشورة" else "مسودة"
                textSize = 12f
                setTextColor(if (published) 0xFF2E8F79.toInt() else AdminUi.GOLD)
                setPadding(0, 0, 0, AdminUi.dp(this@ManageStoriesActivity, 8))
            })

            val actions = LinearLayout(this)
            val edit = AdminUi.button(this, "تعديل")
            val preview = AdminUi.button(this, "معاينة")
            val more = AdminUi.button(this, "المزيد")
            actions.addView(edit, LinearLayout.LayoutParams(0, -2, 1f))
            actions.addView(preview, LinearLayout.LayoutParams(0, -2, 1f).apply {
                marginStart = AdminUi.dp(this@ManageStoriesActivity, 6)
            })
            actions.addView(more, LinearLayout.LayoutParams(0, -2, 1f).apply {
                marginStart = AdminUi.dp(this@ManageStoriesActivity, 6)
            })
            card.addView(actions)

            edit.setOnClickListener {
                showEditor(
                    id = document.id,
                    oldTitle = document.getString("title").orEmpty(),
                    oldContent = document.getString("content").orEmpty(),
                    oldCat = categoryId,
                    oldDesc = document.getString("description").orEmpty(),
                    oldPublished = published
                )
            }
            preview.setOnClickListener { showPreview(title, document.getString("description").orEmpty(), document.getString("content").orEmpty()) }
            more.setOnClickListener { showStoryActions(document, title, published) }

            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = AdminUi.dp(this@ManageStoriesActivity, 10)
            })
        }
    }

    private fun showFilters() {
        val choices = arrayOf(
            "كل القصص",
            "القصص المنشورة",
            "المسودات",
            "الأحدث أولاً",
            "الأقدم أولاً",
            "الأكثر قراءة",
            "ترتيب العنوان"
        )
        AlertDialog.Builder(this)
            .setTitle("تصفية وترتيب القصص")
            .setItems(choices) { _, which ->
                when (which) {
                    0 -> stateFilter = StateFilter.ALL
                    1 -> stateFilter = StateFilter.PUBLISHED
                    2 -> stateFilter = StateFilter.DRAFTS
                    3 -> sortMode = SortMode.NEWEST
                    4 -> sortMode = SortMode.OLDEST
                    5 -> sortMode = SortMode.MOST_READ
                    6 -> sortMode = SortMode.TITLE
                }
                updateFilterLabel()
                renderFiltered()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun updateFilterLabel() {
        val state = when (stateFilter) {
            StateFilter.ALL -> "الكل"
            StateFilter.PUBLISHED -> "منشورة"
            StateFilter.DRAFTS -> "مسودات"
        }
        val sort = when (sortMode) {
            SortMode.NEWEST -> "الأحدث"
            SortMode.OLDEST -> "الأقدم"
            SortMode.MOST_READ -> "الأكثر قراءة"
            SortMode.TITLE -> "العنوان"
        }
        filterButton.text = "$state  •  $sort"
    }

    private fun showStoryActions(document: DocumentSnapshot, title: String, published: Boolean) {
        val toggleText = if (published) "تحويل إلى مسودة" else "نشر القصة"
        val actions = arrayOf(toggleText, "نسخ القصة", "حذف القصة")
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> setPublished(document.id, !published)
                    1 -> duplicateStory(document)
                    2 -> confirmDelete(document.id, title)
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun setPublished(id: String, published: Boolean) {
        db.collection("stories").document(id)
            .update(mapOf("isPublished" to published, "updatedAt" to System.currentTimeMillis()))
            .addOnSuccessListener { loadStories() }
            .addOnFailureListener { status.text = "تعذر تحديث حالة القصة: ${it.localizedMessage.orEmpty()}" }
    }

    private fun duplicateStory(document: DocumentSnapshot) {
        val ref = db.collection("stories").document()
        val data = document.data.orEmpty().toMutableMap()
        data["id"] = ref.id
        data["title"] = "نسخة من: ${document.getString("title").orEmpty()}"
        data["isPublished"] = false
        data["timestamp"] = System.currentTimeMillis()
        data["updatedAt"] = System.currentTimeMillis()
        data["views"] = 0L
        data["rating"] = 0.0
        ref.set(data)
            .addOnSuccessListener { loadStories() }
            .addOnFailureListener { status.text = "تعذر نسخ القصة: ${it.localizedMessage.orEmpty()}" }
    }

    private fun showPreview(title: String, description: String, content: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(AdminUi.dp(this@ManageStoriesActivity, 18), 0, AdminUi.dp(this@ManageStoriesActivity, 18), 0)
        }
        box.addView(TextView(this).apply {
            text = if (description.isBlank()) "بدون وصف مختصر" else description
            textSize = 13f
            setTextColor(AdminUi.MUTED)
        })
        box.addView(TextView(this).apply {
            text = content.ifBlank { "لا يوجد محتوى" }
            textSize = 15f
            setTextColor(0xFF202127.toInt())
            setPadding(0, AdminUi.dp(this@ManageStoriesActivity, 14), 0, 0)
        })
        AlertDialog.Builder(this).setTitle(title).setView(box).setPositiveButton("إغلاق", null).show()
    }

    private fun confirmDelete(id: String, title: String) {
        AlertDialog.Builder(this)
            .setTitle("حذف القصة")
            .setMessage("سيتم حذف «$title» نهائيًا. هل تريد المتابعة؟")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حذف") { _, _ ->
                db.collection("stories").document(id).delete()
                    .addOnSuccessListener { loadStories() }
                    .addOnFailureListener { status.text = "تعذر حذف القصة: ${it.localizedMessage.orEmpty()}" }
            }
            .show()
    }

    private fun showEditor(
        id: String?,
        oldTitle: String = "",
        oldContent: String = "",
        oldCat: String = "",
        oldDesc: String = "",
        oldPublished: Boolean = false
    ) {
        if (categories.isEmpty()) {
            Toast.makeText(this, "أنشئ قسمًا نشطًا أولاً", Toast.LENGTH_LONG).show()
            return
        }

        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(AdminUi.dp(this@ManageStoriesActivity, 18), 0, AdminUi.dp(this@ManageStoriesActivity, 18), 0)
        }
        val title = AdminUi.field(this, "عنوان القصة", oldTitle)
        val description = AdminUi.field(this, "وصف مختصر", oldDesc)
        val content = AdminUi.field(this, "محتوى القصة", oldContent, true)
        form.addView(title)
        form.addView(description, marginParams())
        form.addView(content, marginParams())

        var category = categories.firstOrNull { it.id == oldCat } ?: categories.first()
        val choose = AdminUi.button(this, "القسم: ${category.name}")
        form.addView(choose, marginParams())
        choose.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("اختر القسم")
                .setItems(categories.map { it.name }.toTypedArray()) { _, index ->
                    category = categories[index]
                    choose.text = "القسم: ${category.name}"
                }
                .show()
        }

        val published = CheckBox(this).apply {
            text = "نشر القصة في التطبيق"
            isChecked = if (id == null) false else oldPublished
            setTextColor(AdminUi.NAVY)
        }
        form.addView(published, marginParams())

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (id == null) "إضافة قصة جديدة" else "تعديل القصة")
            .setView(form)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val cleanTitle = title.text?.toString()?.trim().orEmpty()
                val cleanContent = content.text?.toString()?.trim().orEmpty()
                if (cleanTitle.isBlank() || cleanContent.isBlank()) {
                    Toast.makeText(this, "أكمل عنوان القصة ومحتواها", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val ref = if (id == null) db.collection("stories").document() else db.collection("stories").document(id)
                val fields = mutableMapOf<String, Any>(
                    "id" to ref.id,
                    "title" to cleanTitle,
                    "description" to description.text.toString().trim(),
                    "content" to cleanContent,
                    "categoryId" to category.id,
                    "category" to category.id,
                    "categoryName" to category.name,
                    "isPublished" to published.isChecked,
                    "updatedAt" to System.currentTimeMillis()
                )
                if (id == null) {
                    fields["timestamp"] = System.currentTimeMillis()
                    fields["views"] = 0L
                    fields["rating"] = 0.0
                }

                val task = if (id == null) ref.set(fields) else ref.update(fields)
                task.addOnSuccessListener {
                    dialog.dismiss()
                    loadStories()
                }.addOnFailureListener {
                    status.text = "تعذر حفظ القصة: ${it.localizedMessage.orEmpty()}"
                }
            }
        }
        dialog.show()
    }

    private fun isPublished(document: DocumentSnapshot): Boolean = document.getBoolean("isPublished") ?: true

    private fun timestampOf(document: DocumentSnapshot): Long = numberOf(document, "updatedAt").takeIf { it > 0 } ?: numberOf(document, "timestamp")

    private fun numberOf(document: DocumentSnapshot, field: String): Long = (document.get(field) as? Number)?.toLong() ?: 0L

    private fun marginParams() = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = AdminUi.dp(this@ManageStoriesActivity, 9)
    }
}
