package com.khalid.hikaya

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*

class ActivityLogActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = AdminUi.root(this)
        root.addView(AdminUi.title(this, "سجل العمليات", "كل عملية مسجلة من لوحة الإدارة مع اسم المدير ووقتها."))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list, LinearLayout.LayoutParams(-1, -2).apply { topMargin = AdminUi.dp(this@ActivityLogActivity, 18) })
        setContentView(ScrollView(this).apply { addView(root) })
        FirebaseFirestore.getInstance().collection("admin_activity_logs").orderBy("timestamp").limitToLast(100).get()
            .addOnSuccessListener { result ->
                result.documents.reversed().forEach { doc ->
                    val card = AdminUi.card(this)
                    val time = (doc.getLong("timestamp") ?: 0L).takeIf { it > 0 }?.let { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(it)) } ?: "وقت غير متوفر"
                    card.addView(TextView(this).apply { text = doc.getString("action") ?: "عملية إدارية"; textSize = 16f; setTextColor(AdminUi.NAVY); setTypeface(null, 1) })
                    card.addView(TextView(this).apply { text = "${doc.getString("entityId").orEmpty()}  •  ${doc.getString("username").orEmpty()}  •  $time"; textSize = 12f; setTextColor(AdminUi.MUTED); setPadding(0, 6, 0, 0) })
                    list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = AdminUi.dp(this@ActivityLogActivity, 8) })
                }
                if (result.isEmpty) list.addView(TextView(this).apply { text = "لا توجد عمليات مسجلة بعد."; setTextColor(AdminUi.MUTED) })
            }
            .addOnFailureListener { list.addView(TextView(this).apply { text = "تعذر تحميل سجل العمليات: ${it.localizedMessage}"; setTextColor(AdminUi.MUTED) }) }
    }
}
