package com.khalid.hikaya

data class MainSection(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val categories: List<StoryCategory> = emptyList()
)
