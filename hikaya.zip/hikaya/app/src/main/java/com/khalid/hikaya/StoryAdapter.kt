package com.khalid.hikaya

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.khalid.hikaya.databinding.ItemStoryBinding

class StoryAdapter(
    private val originalStories: List<Story>,
    private val onStoryClick: (Story) -> Unit
) : RecyclerView.Adapter<StoryAdapter.StoryViewHolder>() {

    private var visibleStories: List<Story> = originalStories

    fun filter(query: String) {
        val q = query.trim()
        visibleStories = if (q.isEmpty()) {
            originalStories
        } else {
            originalStories.filter {
                it.title.contains(q, ignoreCase = true) ||
                    it.description.contains(q, ignoreCase = true) ||
                    it.category.contains(q, ignoreCase = true)
            }
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoryViewHolder {
        val binding = ItemStoryBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return StoryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: StoryViewHolder, position: Int) {
        holder.bind(visibleStories[position])
    }

    override fun getItemCount(): Int = visibleStories.size

    inner class StoryViewHolder(
        private val binding: ItemStoryBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(story: Story) {
            binding.storyTitle.text = story.title
            binding.storyDescription.text = story.description
            binding.storyRating.text = "★ ${story.rating}"
            binding.storyCategory.text = story.category
            binding.root.setOnClickListener { onStoryClick(story) }
        }
    }
}
