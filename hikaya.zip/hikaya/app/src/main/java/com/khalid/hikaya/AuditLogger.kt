package com.khalid.hikaya

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

object AuditLogger {
    fun log(context: Context, action: String, entityId: String = "") {
        val user = FirebaseAuth.getInstance().currentUser ?: return
        FirebaseFirestore.getInstance().collection("admin_activity_logs").add(
            mapOf(
                "action" to action,
                "entityId" to entityId,
                "username" to (user.displayName ?: AdminAuth.USERNAME),
                "uid" to user.uid,
                "timestamp" to System.currentTimeMillis()
            )
        )
    }
}
