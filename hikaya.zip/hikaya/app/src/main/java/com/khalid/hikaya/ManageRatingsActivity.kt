package com.khalid.hikaya

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore

class ManageRatingsActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private var docs = listOf<DocumentSnapshot>()
    private var query = ""
    private var lowOnly = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = AdminUi.root(this)
        root.addView(AdminUi.title(this, "إدارة التقييمات", "تابع جودة القصص واكتشف التقييمات المنخفضة."))
        val search = AdminUi.search(this, "ابحث بمعرف القصة أو المستخدم...")
        root.addView(search, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 50)).apply { topMargin = AdminUi.dp(this@ManageRatingsActivity, 18) })
        val filter = AdminUi.button(this, "كل التقييمات")
        root.addView(filter, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 46)).apply { topMargin = AdminUi.dp(this@ManageRatingsActivity, 10) })
        status = TextView(this).apply { setTextColor(AdminUi.MUTED); textSize = 13f; setPadding(0, 14, 0, 8) }
        root.addView(status)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        filter.setOnClickListener {
            lowOnly = !lowOnly
            filter.text = if (lowOnly) "التقييمات المنخفضة فقط" else "كل التقييمات"
            render()
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s?.toString().orEmpty(); render() }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    override fun onResume() { super.onResume(); if (::list.isInitialized) load() }

    private fun load() {
        status.text = "جارٍ تحميل التقييمات…"
        db.collection("ratings").get().addOnSuccessListener {
            docs = it.documents.sortedByDescending { d -> number(d, "createdAt") }
            render()
        }.addOnFailureListener { status.text = "تعذر تحميل التقييمات: ${it.localizedMessage.orEmpty()}" }
    }

    private fun render() {
        if (!::list.isInitialized) return
        val q = query.trim()
        val items = docs.filter { d ->
            val rating = number(d, "rating").toInt()
            val story = d.getString("storyId").orEmpty()
            val user = d.getString("userId").orEmpty()
            (!lowOnly || rating <= 4) && (q.isBlank() || story.contains(q, true) || user.contains(q, true))
        }
        status.text = "${items.size} تقييم من ${docs.size}"
        list.removeAllViews()
        if (items.isEmpty()) {
            list.addView(TextView(this).apply { text = "لا توجد تقييمات مطابقة"; setTextColor(AdminUi.MUTED); setPadding(0, 18, 0, 0) })
            return
        }
        items.forEach { document ->
            val rating = number(document, "rating").toInt()
            val card = AdminUi.card(this)
            card.addView(TextView(this).apply { text = "${"★".repeat(rating.coerceIn(0, 10))}  ($rating/10)"; textSize = 18f; setTextColor(if (rating <= 4) 0xFFB66A3C.toInt() else AdminUi.GOLD); setTypeface(null, 1) })
            card.addView(TextView(this).apply { text = "القصة: ${document.getString("storyId").orEmpty()}  •  المستخدم: ${document.getString("userId").orEmpty()}"; textSize = 12f; setTextColor(AdminUi.MUTED); setPadding(0, 7, 0, 8) })
            val delete = AdminUi.button(this, "حذف التقييم وإعادة الحساب")
            card.addView(delete)
            delete.setOnClickListener { deleteRating(document) }
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
    }

    private fun deleteRating(document: DocumentSnapshot) {
        AlertDialog.Builder(this).setTitle("حذف التقييم").setMessage("سيُعاد احتساب متوسط تقييم القصة بعد الحذف.")
            .setNegativeButton("إلغاء", null).setPositiveButton("حذف") { _, _ ->
                db.collection("ratings").document(document.id).delete()
                    .addOnSuccessListener {
                        recalculateStory(document.getString("storyId").orEmpty())
                        load()
                    }
                    .addOnFailureListener { status.text = "تعذر حذف التقييم: ${it.localizedMessage.orEmpty()}" }
            }.show()
    }

    private fun recalculateStory(storyId: String) {
        if (storyId.isBlank()) return
        db.collection("ratings").whereEqualTo("storyId", storyId).get().addOnSuccessListener { result ->
            val ratings = result.documents.map { number(it, "rating").toDouble() }
            val average = ratings.average().takeIf { !it.isNaN() } ?: 0.0
            db.collection("stories").document(storyId).update(
                "rating", average,
                "ratingCount", ratings.size,
                "updatedAt", System.currentTimeMillis()
            )
        }
    }

    private fun number(d: DocumentSnapshot, key: String) = (d.get(key) as? Number)?.toLong() ?: 0L
}
