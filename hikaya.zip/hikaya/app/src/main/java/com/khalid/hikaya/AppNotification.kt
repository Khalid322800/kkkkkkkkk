package com.khalid.hikaya

data class AppNotification(
    val id: String = "",
    val title: String = "",
    val body: String = "",
    val storyId: String? = null,        // إذا كان الإشعار مرتبطاً بقصة محدودة
    val imageUrl: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "SENT"        // SENT, DRAFT, FAILED
) {
    fun toMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "title" to title,
            "body" to body,
            "storyId" to storyId,
            "imageUrl" to imageUrl,
            "timestamp" to timestamp,
            "status" to status
        )
    }
}
