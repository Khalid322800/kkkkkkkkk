package com.khalid.hikaya

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class AnalyticsActivity : AppCompatActivity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private lateinit var root: LinearLayout
    private lateinit var chart: AnalyticsChartView
    private lateinit var chartStatus: TextView
    private var days = 7
    private var dailyDocs = listOf<DocumentSnapshot>()
    private var storyDocs = listOf<DocumentSnapshot>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        root = AdminUi.root(this)
        scroll.addView(root)
        setContentView(scroll)
        buildUi()
        load()
    }

    private fun buildUi() {
        root.addView(AdminUi.title(this, "التحليلات والرسوم البيانية", "قراءة حقيقية من Firebase دون أرقام افتراضية."))
        val periodRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL }
        listOf(7 to "7 أيام", 30 to "30 يومًا", 90 to "90 يومًا").forEach { (value, label) ->
            val button = AdminUi.button(this, label, value == days)
            button.setOnClickListener { days = value; updateChart(); rebuildPeriodButtons(periodRow) }
            periodRow.addView(button, LinearLayout.LayoutParams(0, AdminUi.dp(this, 46), 1f).apply { marginStart = AdminUi.dp(this@AnalyticsActivity, 4); marginEnd = AdminUi.dp(this@AnalyticsActivity, 4) })
        }
        root.addView(periodRow, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 50)).apply { topMargin = AdminUi.dp(this@AnalyticsActivity, 18) })

        val chartCard = AdminUi.card(this)
        chartCard.addView(TextView(this).apply { text = "المشاهدات اليومية"; textSize = 18f; setTextColor(AdminUi.NAVY); setTypeface(null, 1) })
        chartStatus = TextView(this).apply { text = "جارٍ تحميل البيانات…"; textSize = 12f; setTextColor(AdminUi.MUTED); setPadding(0, 5, 0, 8) }
        chartCard.addView(chartStatus)
        chart = AnalyticsChartView(this)
        chartCard.addView(chart, LinearLayout.LayoutParams(-1, AdminUi.dp(this, 240)))
        root.addView(chartCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = AdminUi.dp(this@AnalyticsActivity, 14) })

        val summary = AdminUi.card(this)
        summary.tag = "summary"
        root.addView(summary, LinearLayout.LayoutParams(-1, -2).apply { topMargin = AdminUi.dp(this@AnalyticsActivity, 12) })
        addSummary(summary, "ملخص الفترة", "جارٍ تحميل بيانات التحليلات…")

        val top = AdminUi.card(this)
        top.tag = "top"
        root.addView(top, LinearLayout.LayoutParams(-1, -2).apply { topMargin = AdminUi.dp(this@AnalyticsActivity, 12) })
        addSummary(top, "الأكثر قراءة", "لا توجد بيانات بعد")
    }

    private fun rebuildPeriodButtons(row: LinearLayout) {
        row.removeAllViews()
        listOf(7 to "7 أيام", 30 to "30 يومًا", 90 to "90 يومًا").forEach { (value, label) ->
            val button = AdminUi.button(this, label, value == days)
            button.setOnClickListener { days = value; updateChart(); rebuildPeriodButtons(row) }
            row.addView(button, LinearLayout.LayoutParams(0, AdminUi.dp(this, 46), 1f).apply { marginStart = AdminUi.dp(this@AnalyticsActivity, 4); marginEnd = AdminUi.dp(this@AnalyticsActivity, 4) })
        }
    }

    private fun load() {
        AdminAuth.verifyCurrentAdmin { isAdmin, _ ->
            if (!isAdmin) { chartStatus.text = "جلسة المدير غير صالحة"; return@verifyCurrentAdmin }
            db.collection("stories").get().addOnSuccessListener { storyDocs = it.documents; updateSummary(); updateTopStories() }
                .addOnFailureListener { chartStatus.text = "تعذر تحميل القصص: ${it.localizedMessage.orEmpty()}" }
            db.collection("daily_analytics").get().addOnSuccessListener { dailyDocs = it.documents; updateChart(); updateSummary() }
                .addOnFailureListener { chartStatus.text = "لا تتوفر بيانات يومية بعد. أنشئ daily_analytics لاحقًا لتفعيل الرسم."; chart.submit(emptyList()) }
        }
    }

    private fun updateChart() {
        val today = LocalDate.now()
        val start = today.minusDays((days - 1).toLong())
        val formatter = DateTimeFormatter.ISO_LOCAL_DATE
        val values = dailyDocs.associateBy { it.id }
        val points = (0 until days).map { offset ->
            val date = start.plusDays(offset.toLong())
            val doc = values[date.format(formatter)]
            AnalyticsChartView.Point(date.format(DateTimeFormatter.ofPattern("MM-dd", Locale.US)), number(doc, "views"))
        }
        val hasData = points.any { it.value > 0 }
        chart.submit(if (hasData) points else emptyList(), "لا توجد مشاهدات يومية للفترة المحددة")
        chartStatus.text = if (hasData) "الفترة: آخر $days يومًا • المصدر: daily_analytics" else "لا توجد بيانات يومية مسجلة للفترة المحددة"
    }

    private fun updateSummary() {
        val card = root.findViewWithTag<LinearLayout>("summary") ?: return
        card.removeAllViews()
        val totalViews = storyDocs.sumOf { number(it, "views") }
        val ratings = storyDocs.mapNotNull { it.getDouble("rating") ?: (it.getLong("rating")?.toDouble()) }
        val average = ratings.average().takeIf { !it.isNaN() }
        addSummary(card, "ملخص القراءة", "إجمالي المشاهدات الحالية: ${DashboardStats.formatInteger(totalViews)}\nمتوسط التقييم: ${average?.let { "%.1f".format(Locale.US, it) } ?: "—"}\nالبيانات اليومية: ${if (dailyDocs.isEmpty()) "غير متوفرة" else "متوفرة"}")
    }

    private fun updateTopStories() {
        val card = root.findViewWithTag<LinearLayout>("top") ?: return
        card.removeAllViews()
        addSummary(card, "الأكثر قراءة", "")
        val top = storyDocs.sortedByDescending { number(it, "views") }.take(5)
        if (top.isEmpty() || top.all { number(it, "views") == 0L }) {
            card.addView(TextView(this).apply { text = "لا تتوفر قراءات مسجلة بعد"; setTextColor(AdminUi.MUTED); setPadding(0, 8, 0, 0) })
        } else top.forEachIndexed { index, doc ->
            card.addView(TextView(this).apply { text = "${index + 1}. ${doc.getString("title").orEmpty().ifBlank { "قصة بدون عنوان" }} — ${DashboardStats.formatInteger(number(doc, "views"))} قراءة"; textSize = 13f; setTextColor(0xFF202127.toInt()); setPadding(0, 7, 0, 0) })
        }
    }

    private fun addSummary(card: LinearLayout, title: String, body: String) {
        card.addView(TextView(this).apply { text = title; textSize = 17f; setTextColor(AdminUi.NAVY); setTypeface(null, 1) })
        if (body.isNotBlank()) card.addView(TextView(this).apply { text = body; textSize = 13f; setTextColor(AdminUi.MUTED); setPadding(0, 7, 0, 0) })
    }

    private fun number(document: DocumentSnapshot?, field: String): Long = (document?.get(field) as? Number)?.toLong() ?: 0L
}
