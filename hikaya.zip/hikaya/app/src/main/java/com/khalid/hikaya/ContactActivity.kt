package com.khalid.hikaya

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.khalid.hikaya.databinding.ActivityContactBinding

class ContactActivity : AppCompatActivity() {
    private lateinit var binding: ActivityContactBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityContactBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backButton.setOnClickListener { finish() }
        binding.whatsappRow.setOnClickListener {
            openExternal("https://wa.me/967776532240")
        }
        binding.telegramRow.setOnClickListener {
            openExternal("https://t.me/KHALID_KKKKKKK")
        }
        binding.emailRow.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:khalidgunyim@gmail.com")
                putExtra(Intent.EXTRA_SUBJECT, "التواصل مع مطور تطبيق حكاية")
            }
            try { startActivity(intent) } catch (_: Exception) {
                Toast.makeText(this, "لا يوجد تطبيق بريد إلكتروني متاح", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun openExternal(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show() }
    }
}
