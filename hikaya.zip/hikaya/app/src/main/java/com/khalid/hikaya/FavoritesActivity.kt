
package com.khalid.hikaya

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.khalid.hikaya.databinding.ActivityFavoritesBinding

class FavoritesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFavoritesBinding
    private lateinit var adapter: StoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityFavoritesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backButton.setOnClickListener {
            finish()
        }

        binding.favoritesList.layoutManager = LinearLayoutManager(this)

        adapter = StoryAdapter(emptyList()) { story ->
            openStory(story.id)
        }

        binding.favoritesList.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        loadFavorites()
    }

    private fun loadFavorites() {
        val favoriteStories = StoryRepository.allStories().filter { story ->
            val numericId = story.id.toIntOrNull()

            numericId != null &&
                StoryReaderStore.isFavorite(this, numericId)
        }

        adapter = StoryAdapter(favoriteStories) { story ->
            openStory(story.id)
        }

        binding.favoritesList.adapter = adapter

        val isEmpty = favoriteStories.isEmpty()

        binding.emptyText.visibility =
            if (isEmpty) View.VISIBLE else View.GONE

        binding.favoritesList.visibility =
            if (isEmpty) View.GONE else View.VISIBLE
    }

    private fun openStory(storyId: String) {
        val intent = Intent(this, StoryActivity::class.java)
            .putExtra(StoryActivity.EXTRA_STORY_ID, storyId)

        startActivity(intent)
    }
}
