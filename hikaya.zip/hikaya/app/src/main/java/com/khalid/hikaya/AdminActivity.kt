package com.khalid.hikaya

import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

/** لوحة التحكم الرئيسية: الإحصائيات تُقرأ مباشرة من Firestore. */
class AdminActivity : AppCompatActivity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private var storiesListener: ListenerRegistration? = null
    private var categoriesListener: ListenerRegistration? = null
    private var accessVerified = false
    private var loadingStats = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)
        showLoadingStats()
        verifyAccess()
    }

    override fun onStart() {
        super.onStart()
        if (accessVerified) attachStatsListeners()
    }

    override fun onStop() {
        storiesListener?.remove()
        categoriesListener?.remove()
        storiesListener = null
        categoriesListener = null
        super.onStop()
    }

    private fun verifyAccess() {
        AdminAuth.verifyCurrentAdmin { isAdmin, username ->
            if (!isAdmin) {
                AdminAuth.signOut()
                startActivity(Intent(this, AdminLoginActivity::class.java))
                finish()
                return@verifyCurrentAdmin
            }

            accessVerified = true
            setupHeader(username ?: AdminAuth.USERNAME)
            setupQuickActions()
            attachStatsListeners()
        }
    }

    private fun setupHeader(username: String) {
        findViewById<TextView>(R.id.adminGreeting).text = "مرحباً، $username"
        findViewById<ImageButton>(R.id.adminBackButton).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.adminNotificationsButton).setOnClickListener {
            open(NotificationsActivity::class.java)
        }
        findViewById<ImageButton>(R.id.adminMenuButton).setOnClickListener { showAdminMenu() }
        findViewById<TextView>(R.id.returnToApp).setOnClickListener { finish() }
        findViewById<TextView>(R.id.adminRefreshButton).setOnClickListener { refreshStats() }
        findViewById<TextView>(R.id.adminNavHome).setOnClickListener { refreshStats() }
        findViewById<TextView>(R.id.adminNavStories).setOnClickListener {
            open(ManageStoriesActivity::class.java)
        }
        findViewById<TextView>(R.id.adminNavSections).setOnClickListener {
            open(ManageSectionsActivity::class.java)
        }
        findViewById<TextView>(R.id.adminNavMore).setOnClickListener { showAdminMenu() }

        findViewById<EditText>(R.id.adminSearch).setOnEditorActionListener { view, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                searchStories(view.text.toString())
                true
            } else {
                false
            }
        }
    }

    private fun setupQuickActions() {
        findViewById<MaterialButton>(R.id.actionAddStory).setOnClickListener {
            open(ManageStoriesActivity::class.java)
        }
        findViewById<MaterialButton>(R.id.actionAddSection).setOnClickListener {
            open(ManageSectionsActivity::class.java)
        }
        findViewById<MaterialButton>(R.id.actionManageStories).setOnClickListener {
            open(ManageStoriesActivity::class.java)
        }
        findViewById<MaterialButton>(R.id.actionManageSections).setOnClickListener {
            open(ManageSectionsActivity::class.java)
        }
        findViewById<MaterialButton>(R.id.actionImport).setOnClickListener {
            open(ImportStoriesActivity::class.java)
        }
        findViewById<MaterialButton>(R.id.actionNotification).setOnClickListener {
            open(NotificationsActivity::class.java)
        }
        findViewById<TextView>(R.id.showAllActions).setOnClickListener { showAdminMenu() }
        findViewById<TextView>(R.id.showAllStories).setOnClickListener {
            open(ManageStoriesActivity::class.java)
        }
    }

    private fun attachStatsListeners() {
        storiesListener?.remove()
        categoriesListener?.remove()
        loadingStats = true
        setStatus("جارٍ مزامنة الإحصائيات من Firebase…")

        storiesListener = db.collection("stories")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    setText(R.id.statStories, "—")
                    setText(R.id.statViews, "—")
                    setText(R.id.statRating, "—")
                    loadingStats = false
                    setStatus("تعذر تحميل إحصائيات القصص. اضغط «تحديث» للمحاولة مرة أخرى.")
                    return@addSnapshotListener
                }

                val stats = DashboardStats.fromStories(snapshot.documents)
                setText(R.id.statStories, stats.stories.toString())
                setText(R.id.statViews, DashboardStats.formatInteger(stats.views))
                setText(
                    R.id.statRating,
                    if (stats.averageRating <= 0.0) "—" else "${DashboardStats.formatRating(stats.averageRating)} ★"
                )
                loadingStats = false
                setStatus("آخر تحديث: تم جلب ${stats.stories} قصة من Firebase")
            }

        categoriesListener = db.collection("categories")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    setText(R.id.statUsers, "—")
                    if (!loadingStats) setStatus("تعذر تحميل الأقسام. اضغط «تحديث» للمحاولة مرة أخرى.")
                    return@addSnapshotListener
                }
                val activeCategories = snapshot.documents.count { it.getBoolean("isActive") != false }
                setText(R.id.statUsers, activeCategories.toString())
            }
    }

    private fun refreshStats() {
        if (!accessVerified) return
        showLoadingStats()
        attachStatsListeners()
    }

    private fun searchStories(rawQuery: String) {
        val query = rawQuery.trim()
        if (query.isBlank()) {
            setStatus("اكتب عنوانًا للبحث عن قصة")
            return
        }
        open(Intent(this, AdminSearchActivity::class.java).putExtra(AdminSearchActivity.EXTRA_QUERY, query))
    }

    private fun showAdminMenu() {
        val options = arrayOf(
            "البحث الشامل",
            "إدارة القصص",
            "إدارة الأقسام والفروع",
            "مركز المراجعة والبلاغات",
            "مراجعة التعليقات",
            "إدارة التقييمات",
            "التحليلات والرسوم البيانية",
            "المستخدمون والصلاحيات",
            "سجل العمليات",
            "إعدادات الاتصال",
            "استيراد القصص",
            "الإشعارات",
            "تسجيل الخروج"
        )
        AlertDialog.Builder(this)
            .setTitle("قائمة الإدارة")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> open(AdminSearchActivity::class.java)
                    1 -> open(ManageStoriesActivity::class.java)
                    2 -> open(ManageSectionsActivity::class.java)
                    3 -> open(ModerationReviewActivity::class.java)
                    4 -> open(ManageCommentsActivity::class.java)
                    5 -> open(ManageRatingsActivity::class.java)
                    6 -> open(AnalyticsActivity::class.java)
                    7 -> open(AdminUsersActivity::class.java)
                    8 -> open(ActivityLogActivity::class.java)
                    9 -> open(AdminSettingsActivity::class.java)
                    10 -> open(ImportStoriesActivity::class.java)
                    11 -> open(NotificationsActivity::class.java)
                    12 -> {
                        AdminAuth.signOut()
                        startActivity(Intent(this, AdminLoginActivity::class.java))
                        finish()
                    }
                }
            }
            .show()
    }

    private fun showLoadingStats() {
        setText(R.id.statStories, "…")
        setText(R.id.statUsers, "…")
        setText(R.id.statViews, "…")
        setText(R.id.statRating, "…")
        setStatus("جارٍ تحميل بيانات لوحة الإدارة…")
    }

    private fun setStatus(message: String) {
        findViewById<TextView>(R.id.adminDataStatus).text = message
    }

    private fun setText(id: Int, value: String) {
        findViewById<TextView>(id).text = value
    }

    private fun open(target: Class<*>) {
        startActivity(Intent(this, target))
    }

    private fun open(intent: Intent) {
        startActivity(intent)
    }
}
