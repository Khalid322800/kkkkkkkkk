
package com.khalid.hikaya

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object StoryReaderStore {

    private const val PREFS = "hikaya_reader_store"
    private const val FAVORITES = "favorites"
    private const val RATINGS = "ratings"
    private const val PENDING_RATINGS = "pending_ratings"
    private const val COMMENTS = "comments"
    private const val PENDING_COMMENTS = "pending_comments"
    private const val BOOKMARKS = "bookmarks"
    private const val POSITIONS = "positions"
    private const val SAVE_POSITION = "save_position"
    private const val SETTINGS = "settings"

    data class Comment(
        val id: String,
        val userId: String,
        val name: String,
        val text: String,
        val time: String
    )

    data class Bookmark(
        val offset: Int,
        val selectedText: String,
        val label: String
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // المفضلة

    fun isFavorite(context: Context, storyId: Int): Boolean {
        return prefs(context)
            .getStringSet(FAVORITES, emptySet())
            ?.contains(storyId.toString()) == true
    }

    fun toggleFavorite(context: Context, storyId: Int): Boolean {
        val p = prefs(context)

        val set = p.getStringSet(FAVORITES, emptySet())
            ?.toMutableSet() ?: mutableSetOf()

        val key = storyId.toString()

        val enabled = if (set.contains(key)) {
            set.remove(key)
            false
        } else {
            set.add(key)
            true
        }

        p.edit()
            .putStringSet(FAVORITES, set)
            .apply()

        return enabled
    }

    // التقييمات

    fun hasRated(context: Context, storyId: Int): Boolean {
        return prefs(context)
            .getStringSet(RATINGS, emptySet())
            ?.contains(storyId.toString()) == true
    }

    fun getMyRating(context: Context, storyId: Int): Int {
        return prefs(context).getInt("rating_$storyId", 0)
    }

    fun queueRating(context: Context, storyId: Int, rating: Int) {
        val p = prefs(context)
        val user = UserManager.get(context) ?: return

        val rated = p.getStringSet(RATINGS, emptySet())
            ?.toMutableSet() ?: mutableSetOf()

        val pending = p.getStringSet(PENDING_RATINGS, emptySet())
            ?.toMutableSet() ?: mutableSetOf()

        rated.add(storyId.toString())
        pending.add(storyId.toString())

        p.edit()
            .putInt("rating_$storyId", rating)
            .putString("rating_user_$storyId", user.userId)
            .putStringSet(RATINGS, rated)
            .putStringSet(PENDING_RATINGS, pending)
            .apply()

        CloudModerationSync.syncRating(context, storyId, user.userId, rating)
        SyncManager.requestSync(context)
    }

    fun pendingRatingIds(context: Context): Set<String> {
        return prefs(context)
            .getStringSet(PENDING_RATINGS, emptySet())
            ?.toSet() ?: emptySet()
    }

    fun getPendingRatingUserId(
        context: Context,
        storyId: Int
    ): String? {
        return prefs(context).getString("rating_user_$storyId", null)
    }

    fun markRatingSynced(context: Context, storyId: Int) {
        val p = prefs(context)

        val pending = p.getStringSet(PENDING_RATINGS, emptySet())
            ?.toMutableSet() ?: mutableSetOf()

        pending.remove(storyId.toString())

        p.edit()
            .putStringSet(PENDING_RATINGS, pending)
            .apply()
    }

    // التعليقات

    fun getComments(
        context: Context,
        storyId: Int
    ): List<Comment> {
        val raw = prefs(context)
            .getString("comments_$storyId", "[]") ?: "[]"

        return try {
            val array = JSONArray(raw)

            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)

                    add(
                        Comment(
                            id = o.optString("id", "legacy-$i"),
                            userId = o.optString("userId", ""),
                            name = o.optString("name", "مستخدم حكاية"),
                            text = o.optString("text", ""),
                            time = o.optString("time", "")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun addComment(
        context: Context,
        storyId: Int,
        text: String,
        time: String
    ) {
        val user = UserManager.get(context) ?: return
        val commentId = "c_${UUID.randomUUID()}"

        val array = JSONArray()

        getComments(context, storyId).forEach { comment ->
            array.put(
                JSONObject()
                    .put("id", comment.id)
                    .put("userId", comment.userId)
                    .put("name", comment.name)
                    .put("text", comment.text)
                    .put("time", comment.time)
            )
        }

        array.put(
            JSONObject()
                .put("id", commentId)
                .put("userId", user.userId)
                .put("name", user.username)
                .put("text", text)
                .put("time", time)
        )

        val p = prefs(context)

        val pending = p.getStringSet(PENDING_COMMENTS, emptySet())
            ?.toMutableSet() ?: mutableSetOf()

        pending.add(commentId)

        p.edit()
            .putString("comments_$storyId", array.toString())
            .putStringSet(PENDING_COMMENTS, pending)
            .apply()

        CloudModerationSync.syncComment(
            context,
            storyId,
            Comment(commentId, user.userId, user.username, text, time)
        )
        SyncManager.requestSync(context)
    }

    fun pendingCommentIds(context: Context): Set<String> {
        return prefs(context)
            .getStringSet(PENDING_COMMENTS, emptySet())
            ?.toSet() ?: emptySet()
    }

    fun getPendingComments(
        context: Context
    ): List<Pair<Int, Comment>> {
        val pending = pendingCommentIds(context)

        if (pending.isEmpty()) {
            return emptyList()
        }

        val result = mutableListOf<Pair<Int, Comment>>()

        // allStories() دالة، لذلك يجب استدعاؤها بالأقواس.
        StoryRepository.allStories().forEach { story ->
            val numericStoryId = story.id.toIntOrNull()
                ?: return@forEach

            getComments(context, numericStoryId).forEach { comment ->
                if (pending.contains(comment.id)) {
                    result.add(numericStoryId to comment)
                }
            }
        }

        return result
    }

    fun markCommentSynced(
        context: Context,
        commentId: String
    ) {
        val p = prefs(context)

        val pending = p.getStringSet(PENDING_COMMENTS, emptySet())
            ?.toMutableSet() ?: mutableSetOf()

        pending.remove(commentId)

        p.edit()
            .putStringSet(PENDING_COMMENTS, pending)
            .apply()
    }

    // الإشارات المرجعية

    fun getBookmarks(
        context: Context,
        storyId: Int
    ): List<Bookmark> {
        val raw = prefs(context)
            .getString("bookmarks_$storyId", "[]") ?: "[]"

        return try {
            val array = JSONArray(raw)

            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)

                    add(
                        Bookmark(
                            offset = o.optInt("offset"),
                            selectedText = o.optString("selectedText", ""),
                            label = o.optString("label", "")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun addBookmark(
        context: Context,
        storyId: Int,
        offset: Int,
        selectedText: String
    ) {
        val bookmarks = getBookmarks(context, storyId)
        val array = JSONArray()

        bookmarks.forEach { bookmark ->
            array.put(
                JSONObject()
                    .put("offset", bookmark.offset)
                    .put("selectedText", bookmark.selectedText)
                    .put("label", bookmark.label)
            )
        }

        val label = selectedText.ifBlank {
            "موضع ${bookmarks.size + 1}"
        }

        array.put(
            JSONObject()
                .put("offset", offset)
                .put("selectedText", selectedText)
                .put("label", label.take(45))
        )

        prefs(context).edit()
            .putString("bookmarks_$storyId", array.toString())
            .apply()
    }

    // حفظ موضع القراءة

    fun isSavePositionEnabled(context: Context): Boolean {
        return prefs(context).getBoolean(SAVE_POSITION, true)
    }

    fun setSavePositionEnabled(
        context: Context,
        enabled: Boolean
    ) {
        prefs(context).edit()
            .putBoolean(SAVE_POSITION, enabled)
            .apply()
    }

    fun savePosition(
        context: Context,
        storyId: Int,
        y: Int
    ) {
        if (isSavePositionEnabled(context)) {
            prefs(context).edit()
                .putInt("position_$storyId", y)
                .apply()
        }
    }

    fun getPosition(context: Context, storyId: Int): Int {
        return prefs(context).getInt("position_$storyId", 0)
    }

    // إعدادات القارئ

    fun getInt(
        context: Context,
        key: String,
        default: Int
    ): Int {
        return prefs(context).getInt("$SETTINGS:$key", default)
    }

    fun putInt(context: Context, key: String, value: Int) {
        prefs(context).edit()
            .putInt("$SETTINGS:$key", value)
            .apply()
    }

    fun getFloat(
        context: Context,
        key: String,
        default: Float
    ): Float {
        return prefs(context).getFloat("$SETTINGS:$key", default)
    }

    fun putFloat(context: Context, key: String, value: Float) {
        prefs(context).edit()
            .putFloat("$SETTINGS:$key", value)
            .apply()
    }

    fun getString(
        context: Context,
        key: String,
        default: String
    ): String {
        return prefs(context)
            .getString("$SETTINGS:$key", default) ?: default
    }

    fun putString(
        context: Context,
        key: String,
        value: String
    ) {
        prefs(context).edit()
            .putString("$SETTINGS:$key", value)
            .apply()
    }
}
