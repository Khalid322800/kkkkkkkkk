package com.khalid.hikaya

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

/** الصفحة الرئيسية بتصميم أدبي فاخر، مع مدخل إدارة مخفي بالضغط المطوّل على شعار حكاية. */
class MainActivity : AppCompatActivity() {
    private val db by lazy { FirebaseFirestore.getInstance() }

    private lateinit var dynamicListLayout: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnSettings: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!UserManager.isConfigured(this)) {
            startActivity(Intent(this, UserSetupActivity::class.java))
            finish()
            return
        }

        SyncManager.requestSync(this)
        FcmTokenRegistrar.registerCurrentDevice()

        if (
            android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9001)
        }

        setContentView(R.layout.activity_main)

        // مدخل الإدارة المخفي: لا يعمل إلا عند الضغط المطوّل على كلمة «حكاية».
        val hikayaLogo = findViewById<TextView>(R.id.tvHikayaLogo)
        hikayaLogo.setOnLongClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            startActivity(Intent(this@MainActivity, AdminLoginActivity::class.java))
            true
        }

        dynamicListLayout = findViewById(R.id.dynamicListLayout)
        tvStatus = findViewById(R.id.tvStatus)
        progressBar = findViewById(R.id.progressBar)
        btnSettings = findViewById(R.id.btnSettings)

        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        if (::dynamicListLayout.isInitialized) {
            loadRootCategories()
        }
    }

    private fun loadRootCategories() {
        progressBar.visibility = View.VISIBLE
        tvStatus.visibility = View.GONE
        dynamicListLayout.removeAllViews()
       db.collection("categories")
    .whereEqualTo("isActive", true)
    .get()
            .addOnSuccessListener { result ->
                progressBar.visibility = View.GONE
                val roots = result.documents.mapNotNull { doc ->
                    val data = doc.data ?: return@mapNotNull null
                    val parent = data["parentId"] as? String
                    if (parent.isNullOrBlank() && data["isActive"] != false) {
                        CategoryBranch(
                            id = doc.id,
                            name = data["name"] as? String ?: "",
                            description = data["description"] as? String ?: "",
                            icon = data["icon"] as? String ?: "folder",
                            parentId = null,
                            order = (data["order"] as? Number)?.toInt() ?: 0,
                            isActive = true
                        )
                    } else {
                        null
                    }
                }.filter { it.name.isNotBlank() }.sortedBy { it.order }

                if (roots.isEmpty()) {
                    tvStatus.text = "مكتبتك هادئة وخالية الآن.\nأضف أول قسم من لوحة التحكم لتزهر الحكايات."
                    tvStatus.visibility = View.VISIBLE
                } else {
                    tvStatus.visibility = View.GONE
                    roots.forEach { category ->
                        dynamicListLayout.addView(
                            categoryCard(category.name, category.description, category.icon) {
                                startActivity(
                                    Intent(this, CategoryActivity::class.java)
                                        .putExtra(CategoryActivity.EXTRA_CATEGORY_ID, category.id)
                                        .putExtra("category_title", category.name)
                                )
                            }
                        )
                    }
                }
            }
            .addOnFailureListener { e ->
                progressBar.visibility = View.GONE
                tvStatus.visibility = View.VISIBLE
                tvStatus.text = "تعذر تحميل الأقسام. تحقق من الاتصال.\n${e.localizedMessage ?: ""}"
            }
    }

    private fun categoryCard(
        title: String,
        description: String,
        icon: String,
        click: () -> Unit
    ): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.rgb(235, 227, 212))
            }
            elevation = dp(2).toFloat()
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }

        val iconView = TextView(this).apply {
            text = iconGlyph(icon)
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(184, 146, 72))
            background = GradientDrawable().apply {
                setColor(Color.rgb(248, 244, 234))
                cornerRadius = dp(14).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }

        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(12), 0)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }

        texts.addView(TextView(this).apply {
            text = title
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(34, 28, 22))
        })

        if (description.isNotBlank()) {
            texts.addView(TextView(this).apply {
                text = description
                textSize = 12.5f
                setTextColor(Color.rgb(128, 118, 105))
                setPadding(0, dp(4), 0, 0)
            })
        }

        val arrowView = TextView(this).apply {
            text = "‹"
            textSize = 24f
            setTextColor(Color.rgb(180, 170, 155))
        }

        card.addView(iconView)
        card.addView(texts)
        card.addView(arrowView)

        return card.also {
            it.layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(14)
            }
        }
    }

    private fun iconGlyph(icon: String): String = when (icon.lowercase()) {
        "book", "book-open", "stories" -> "📖"
        "users", "people" -> "👥"
        "star", "featured" -> "⭐"
        "history" -> "⌛"
        "scroll", "scroll-text" -> "📜"
        "landmark", "islam" -> "🕌"
        "folder-plus" -> "📂"
        else -> "📚"
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
