package com.khalid.hikaya

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/**
 * Network-ready synchronization worker.
 *
 * At this stage there is intentionally no fake server call. Once the Hikaya
 * API/database is available, this worker will upload queued ratings/comments
 * and download the user's current data using UserManager.get(context).userId.
 */
class SyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result {
        val user = UserManager.get(applicationContext) ?: return Result.success()

        // API integration point:
        // 1) upload pending ratings/comments with user.userId
        // 2) pull server changes for user.userId
        // 3) mark successfully uploaded local records as synced
        // Keep the queue untouched until a real server response is available.
        @Suppress("UNUSED_VARIABLE")
        val userId = user.userId

        return Result.success()
    }
}
