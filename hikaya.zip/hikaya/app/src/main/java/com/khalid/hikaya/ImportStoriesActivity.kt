package com.khalid.hikaya

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID

class ImportStoriesActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private val code = 1001
    private var catId = ""
    private var catName = ""
    private var publish = false
    private lateinit var status: TextView
    private val valid = mutableListOf<Map<String, Any>>()
    private val rejected = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = AdminUi.root(this)
        root.addView(AdminUi.title(this, "الاستيراد الاحترافي", "عاين ملفات TXT وJSON، تحقق من القصص، ثم احفظها كمسودات أو منشورات."))
        val card = AdminUi.card(this)
        val category = AdminUi.button(this, "اختيار القسم", false)
        val mode = AdminUi.button(this, "الحالة: مسودة", false)
        val pick = AdminUi.button(this, "اختيار ملفات TXT / JSON", true)
        card.addView(category); card.addView(mode, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 }); card.addView(pick, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = AdminUi.dp(this@ImportStoriesActivity, 20) })
        status = TextView(this).apply { setTextColor(AdminUi.MUTED); textSize = 13f; setPadding(0, 18, 0, 0) }
        root.addView(status); setContentView(root)
        category.setOnClickListener { chooseCategory(category) }
        mode.setOnClickListener { publish = !publish; mode.text = if (publish) "الحالة: منشور" else "الحالة: مسودة" }
        pick.setOnClickListener { chooseFiles() }
    }

    private fun chooseCategory(button: Button) {
        db.collection("categories").get().addOnSuccessListener { result ->
            val categories = result.documents.filter { it.getBoolean("isActive") != false && !it.getString("name").isNullOrBlank() }
            if (categories.isEmpty()) { status.text = "أنشئ قسمًا نشطًا قبل الاستيراد."; return@addOnSuccessListener }
            AlertDialog.Builder(this).setTitle("اختر القسم").setItems(categories.map { it.getString("name")!! }.toTypedArray()) { _, index ->
                catId = categories[index].id; catName = categories[index].getString("name")!!; button.text = "القسم: $catName"
            }.show()
        }.addOnFailureListener { status.text = "تعذر تحميل الأقسام: ${it.localizedMessage}" }
    }

    private fun chooseFiles() {
        if (catId.isBlank()) { status.text = "اختر قسمًا أولًا."; return }
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true); putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/plain", "application/json")) }
        startActivityForResult(Intent.createChooser(intent, "اختر ملفات القصص"), code)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != code || resultCode != Activity.RESULT_OK) return
        valid.clear(); rejected.clear()
        val uris = mutableListOf<Uri>()
        data?.clipData?.let { for (i in 0 until it.itemCount) uris.add(it.getItemAt(i).uri) }
        data?.data?.let { if (uris.isEmpty()) uris.add(it) }
        uris.forEach { parse(it) }
        showPreview()
    }

    private fun parse(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.use { BufferedReader(InputStreamReader(it, "UTF-8")).readText() }.orEmpty()
            if (text.isBlank()) { rejected.add("ملف فارغ"); return }
            val isJson = contentResolver.getType(uri)?.contains("json") == true || text.trim().startsWith("{") || text.trim().startsWith("[")
            if (isJson) {
                if (text.trim().startsWith("[")) { val array = JSONArray(text); for (i in 0 until array.length()) addJson(array.getJSONObject(i)) }
                else addJson(JSONObject(text))
            } else {
                val lines = text.lines().filter { it.isNotBlank() }
                if (lines.size < 2) rejected.add("TXT يحتاج عنوانًا وسطر محتوى") else addStory(lines.first(), lines.drop(1).joinToString("\n"), "")
            }
        } catch (e: Exception) { rejected.add("ملف غير صالح: ${e.localizedMessage.orEmpty()}") }
    }

    private fun addJson(json: JSONObject) = addStory(json.optString("title"), json.optString("content"), json.optString("description"))

    private fun addStory(title: String, content: String, description: String) {
        if (title.isBlank() || content.isBlank()) { rejected.add("قصة بلا عنوان أو محتوى"); return }
        valid.add(mapOf("id" to UUID.randomUUID().toString(), "title" to title.trim(), "content" to content.trim(), "description" to description, "categoryId" to catId, "categoryName" to catName, "category" to catName, "timestamp" to System.currentTimeMillis(), "isPublished" to publish, "views" to 0L, "rating" to 0.0))
    }

    private fun showPreview() {
        AlertDialog.Builder(this).setTitle("معاينة الاستيراد")
            .setMessage("قصص صالحة: ${valid.size}\nقصص مرفوضة: ${rejected.size}\nالحالة: ${if (publish) "منشور" else "مسودة"}")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ الصالح فقط") { _, _ -> saveValid() }.show()
    }

    private fun saveValid() {
        if (valid.isEmpty()) { status.text = "لا توجد قصص صالحة للحفظ."; return }
        val batch = db.batch(); valid.forEach { story -> batch.set(db.collection("stories").document(story["id"] as String), story) }
        status.text = "جارٍ حفظ ${valid.size} قصة…"
        batch.commit().addOnSuccessListener { AuditLogger.log(this, "استيراد قصص", catId); status.text = "تم حفظ ${valid.size} قصة. المرفوض: ${rejected.size}." }
            .addOnFailureListener { status.text = "فشل الحفظ: ${it.localizedMessage}" }
    }
}
