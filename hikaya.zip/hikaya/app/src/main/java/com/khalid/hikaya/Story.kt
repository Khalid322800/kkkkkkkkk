package com.khalid.hikaya

data class Story(
    val id: String = "",
    val title: String = "",
    val content: String = "",
    val description: String = "",
    val category: String = "",
    val imageUrl: String = "",
    val rating: Float = 5.0f,
    val views: Int = 0,
    val duration: Int = 0,
    val timestamp: Long = 0L
)
