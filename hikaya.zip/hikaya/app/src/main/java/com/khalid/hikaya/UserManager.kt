package com.khalid.hikaya

import android.content.Context
import java.util.UUID

object UserManager {
    private const val PREFS = "hikaya_user"
    private const val KEY_USER_ID = "user_id"
    private const val KEY_USERNAME = "username"
    private const val KEY_CREATED_AT = "created_at"

    fun isConfigured(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_USER_ID, null).isNullOrBlank().not() &&
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_USERNAME, null).isNullOrBlank().not()

    fun get(context: Context): UserProfile? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = p.getString(KEY_USER_ID, null)?.takeIf { it.isNotBlank() } ?: return null
        val username = p.getString(KEY_USERNAME, null)?.takeIf { it.isNotBlank() } ?: return null
        return UserProfile(id, username, p.getLong(KEY_CREATED_AT, 0L))
    }

    fun create(context: Context, username: String): UserProfile =
        createWithId(context, generateId(), username)

    fun generateId(): String =
        "HKY-" + UUID.randomUUID().toString().replace("-", "").take(10).uppercase()

    fun createWithId(context: Context, userId: String, username: String): UserProfile {
        val cleanName = username.trim().take(30).ifBlank { "مستخدم حكاية" }
        val cleanId = userId.trim().ifBlank { generateId() }
        val createdAt = System.currentTimeMillis()
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_USER_ID, cleanId)
            .putString(KEY_USERNAME, cleanName)
            .putLong(KEY_CREATED_AT, createdAt)
            .apply()
        return UserProfile(cleanId, cleanName, createdAt)
    }

    fun updateUsername(context: Context, username: String): Boolean {
        val cleanName = username.trim().take(30)
        if (cleanName.isBlank()) return false
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_USERNAME, cleanName)
            .apply()
        return true
    }
}
