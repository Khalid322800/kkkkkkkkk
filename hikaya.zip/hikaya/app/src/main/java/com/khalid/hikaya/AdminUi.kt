package com.khalid.hikaya

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object AdminUi {
    const val NAVY = 0xFF162B43.toInt()
    const val GOLD = 0xFFB0873B.toInt()
    const val BG = 0xFFF6F4EF.toInt()
    const val MUTED = 0xFF77747A.toInt()

    fun dp(context: Context, value: Int) = (value * context.resources.displayMetrics.density).toInt()

    fun root(context: Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setBackgroundColor(BG)
        setPadding(dp(context, 18), dp(context, 18), dp(context, 18), dp(context, 14))
    }

    fun title(context: Context, text: String, subtitle: String): LinearLayout {
        val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        box.addView(TextView(context).apply { this.text = "حكاية  /  لوحة التحكم"; textSize = 12f; setTextColor(GOLD); typeface = Typeface.DEFAULT_BOLD })
        box.addView(TextView(context).apply { this.text = text; textSize = 26f; setTextColor(NAVY); typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(context, 5), 0, dp(context, 3)) })
        box.addView(TextView(context).apply { this.text = subtitle; textSize = 13f; setTextColor(MUTED) })
        return box
    }

    fun search(context: Context, hint: String): EditText = EditText(context).apply {
        this.hint = hint; textSize = 13f; setTextColor(0xFF202127.toInt()); setHintTextColor(0xFF96959A.toInt())
        setSingleLine(true); setPadding(dp(context, 14), 0, dp(context, 14), 0)
        background = rounded(0xFFFFFFFF.toInt(), 16, 0xFFE4DED3.toInt())
    }

    fun button(context: Context, text: String, filled: Boolean = false): Button = Button(context).apply {
        this.text = text; textSize = 12f; isAllCaps = false; setTextColor(if (filled) Color.WHITE else NAVY)
        background = rounded(if (filled) NAVY else 0xFFF1E8D5.toInt(), 14, 0)
        stateListAnimator = null; minHeight = dp(context, 48); setPadding(dp(context, 14), 0, dp(context, 14), 0)
    }

    fun card(context: Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(context, 14), dp(context, 14), dp(context, 14), dp(context, 12))
        background = rounded(Color.WHITE, 16, 0xFFE7E1D7.toInt())
    }

    fun field(context: Context, hint: String, value: String = "", multi: Boolean = false): EditText = EditText(context).apply {
        this.hint = hint; setText(value); textSize = 14f; setTextColor(0xFF202127.toInt()); setHintTextColor(MUTED)
        setPadding(dp(context, 12), dp(context, 10), dp(context, 12), dp(context, 10)); background = rounded(Color.WHITE, 12, 0xFFE0D9CE.toInt())
        if (multi) { minLines = 5; gravity = Gravity.TOP or Gravity.START } else setSingleLine(true)
    }

    fun rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
        if (stroke != 0) setStroke(1, stroke)
    }
}
