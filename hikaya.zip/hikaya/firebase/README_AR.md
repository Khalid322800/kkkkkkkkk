# المرحلة الأولى: حماية لوحة إدارة حكاية

## الملفات

- `firestore.rules`: قواعد Firestore.
- `database.rules.json`: قواعد Realtime Database.
- `firebase.json`: إعداد Firebase CLI.
- `.firebaserc`: مشروع Firebase الحالي `hikayaapp-70750`.
- `../tools/set-admin-claims/`: سكربت تعيين Custom Claims.

## قبل التنفيذ

لا تضع `service-account.json` أو أي مفتاح إداري داخل مستودع Android أو ملف ZIP. استخدم حسابًا إداريًا عبر Application Default Credentials أو متغير `GOOGLE_APPLICATION_CREDENTIALS` خارج مجلد المشروع.

## نشر القواعد بعد مراجعتها

من داخل مجلد `firebase`:

```bash
firebase login
firebase use hikayaapp-70750
firebase deploy --only firestore:rules,database
```

لا تنفذ أمر النشر قبل مراجعة القواعد في Firebase Console والتأكد من أسماء المجموعات الفعلية.

## تعيين Custom Claims

من داخل `tools/set-admin-claims`:

```bash
npm install
GOOGLE_APPLICATION_CREDENTIALS=/path/outside/project/service-account.json npm run set-admin
```

أو باستخدام Application Default Credentials:

```bash
gcloud auth application-default login
npm install
npm run set-admin
```

الحساب المستهدف:

```text
khalid776532240@hikaya.app
```

المطالبات التي يضعها السكربت:

```json
{
  "admin": true,
  "username": "KHALID776532240"
}
```

بعد التعيين، يجب تسجيل الخروج ثم الدخول مجددًا في التطبيق حتى يحصل Firebase على ID Token جديد.

## اختبار ضروري

1. مدير صحيح: يستطيع قراءة وكتابة القصص والأقسام.
2. مستخدم غير مدير: يستطيع القراءة العامة فقط ولا يستطيع الكتابة.
3. حساب بدون Claims: لا يدخل لوحة الإدارة.
4. Realtime Database: لا يستطيع الكتابة في `notifications` إلا المدير.
5. لا توجد مفاتيح Service Account داخل APK أو Git.

## ملاحظة عن التعليقات والتقييمات

التطبيق الحالي يخزن التعليقات والتقييمات محليًا داخل `StoryReaderStore`، لذلك قواعد `comments` و`ratings` هنا تجهيز للمسار المستقبلي وليست ربطًا فعليًا لهذه الشاشة بعد.
